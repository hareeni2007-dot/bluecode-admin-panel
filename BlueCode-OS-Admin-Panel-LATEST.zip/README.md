# BlueCode OS Admin Panel

A standalone React + Vite + Tailwind CSS admin dashboard prototype. It reuses the BlueCode OS wordmark from the supplied frontend reference and keeps all admin modules separate from the founder-facing app.

## Run locally

Requires Node.js 20.19+ or 22.12+.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. To verify the project:

```bash
npm test
npm run build
```

No environment variables are required. `.env.example` is included for reference; it contains no secrets.

## Modules

1. **Dashboard** — illustrative startup totals, AI expenses, Hunter credits, feature activity, founder activity, and subscription summary.
2. **Startup Management** — startup plan/status, founder-wise activity, estimated costs, and engagement scoring.
3. **User Activity Tracking** — aggregate sessions, active days, and feature usage. No keystroke or screen-recording collection.
4. **AI Usage Monitoring** — customer-wise AI requests, tokens, providers, and estimated USD costs.
5. **Prospect Management** — startup-level researched, qualified, decision-maker, and signal counts only.
6. **Email Activity** — aggregate draft, approval, sent, bounce, and reply counts; no recipients or message text.
7. **Subscription Management** — illustrative plans, trial states, payment status, and monthly amounts.
8. **API Management** — Anthropic, OpenAI, and Hunter usage, estimated costs, and local-only monitor controls. Apollo is not included.
9. **Reports & Analytics** — selectable time ranges, feature usage charts, and startup-wise comparisons.
10. **Support & Audit Logs** — issue category totals, role guardrails, and illustrative audit events.

The left navigation uses distinct page paths. Search, status filters, table sorting, pagination, CSV exports, reporting windows, role preview, notifications, and provider monitor controls work with the local demo data.

## Engagement score proposal

The score is the sum of seven configurable behaviours, capped at 100:

| Behaviour | Points |
| --- | ---: |
| Created an ICP | 10 |
| Researched prospects | 15 |
| Used decision-maker discovery | 15 |
| Generated email drafts | 15 |
| Approved and sent emails | 20 |
| Recorded prospect replies | 15 |
| Returned and used the platform again | 10 |

Proposed bands are **At risk** below 40, **Developing** from 40 through 69, and **Engaged** at 70 or above. The bands are configurable and are not validated predictors. Use the score as an internal prompt for follow-up, not as a definitive measure of customer success. The weights and band cutoffs live in `src/admin/engagement.js`.

## Data, privacy, and integration notes

- Every count, account, cost, event, and subscription in this package is illustrative mock data. Dashboard totals represent an illustrative 50-startup platform; detailed tables show representative sample workspaces.
- Dollar values use USD. No billing provider, AI provider, Hunter account, database, email sender, or live admin API is connected. The monitor buttons only change local preview state.
- The UI does not reveal prospect identities, prospect contact details, email recipients, email content, API keys, or secrets.
- The role selector previews **Super Admin**, **Support Admin**, and **Viewer** labels only. Authentication, authorization, tenant isolation, audit persistence, secure service calls, and data retention must be implemented in the teammate-owned backend before production use.
- `src/admin/api-service.js` is the replaceable mock service layer; `src/admin/mock-data.js` keeps sample records out of UI components.
- No Apollo integration was confirmed as active in the received project files, so Apollo is intentionally omitted.

## Source layout

```text
src/
  admin/                 Admin screens, mock data, service layer, scoring, route wrapper
  components/ui/         Shared Button primitive
  lib/                   Small class-name utility
  styles.css             Tailwind v4 and BlueCode design tokens
  main.jsx               Vite entry point
public/                  Local wordmark and favicon
```
