import {
  Activity,
  ArrowLeft,
  ArrowUpRight,
  Building2,
  Check,
  CircleDollarSign,
  Clock3,
  Download,
  Mail,
  Network,
  ShieldCheck,
  Sparkles,
  Target,
  Users,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { adminApi, downloadCsv, getRangeFactor } from "./api-service.js";
import { filterSearchRecords } from "./search.js";
import { DateRangeControls } from "./UserManagement.jsx";

const currency = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

function numberFormat(value) {
  return new Intl.NumberFormat("en-US").format(value);
}

function StatusPill({ children }) {
  const tone = String(children).toLowerCase().replaceAll(" ", "-").replaceAll("·", "");
  return <span className={`admin-status status-${tone}`}>{children}</span>;
}

export function StartupReportView({
  startupId,
  backLabel = "Back to Startup Management",
  onBack,
  range,
  setRange,
  customStart,
  setCustomStart,
  customEnd,
  setCustomEnd,
  search = "",
  onAuditAction,
}) {
  const report = adminApi.getStartupReport(startupId);

  if (!report) {
    return (
      <section className="admin-panel">
        <p className="admin-empty-cell">Startup record not found.</p>
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft aria-hidden="true" /> {backLabel}
        </Button>
      </section>
    );
  }

  const factor = getRangeFactor(range, customStart, customEnd);
  const scale = (val) => Math.max(0, Math.round(val * factor));
  const scaleFloat = (val) => Number((val * factor).toFixed(2));
  const m = report.metrics;

  const activityMetrics = [
    { key: "icpsCreated", label: "ICPs created", value: numberFormat(m.icpsCreated), note: "Workspace ICP definitions (non-scaled)" },
    { key: "prospectsResearched", label: "Prospects researched", value: numberFormat(scale(m.prospectsResearched)), note: "Accounts researched in period" },
    { key: "decisionMakersIdentified", label: "Decision-makers identified", value: numberFormat(scale(m.decisionMakersIdentified)), note: "Contacts discovered (identities hidden)" },
    { key: "prospectsQualified", label: "Prospects qualified", value: numberFormat(scale(m.prospectsQualified)), note: "Matched ICP qualification criteria" },
    { key: "buyingSignalsAnalyzed", label: "Buying signals analysed", value: numberFormat(scale(m.buyingSignalsAnalyzed)), note: "Intent & trigger signals processed" },
    { key: "emailDraftsGenerated", label: "Email drafts generated", value: numberFormat(scale(m.emailDraftsGenerated)), note: "AI-assisted outreach drafts" },
    { key: "emailsApproved", label: "Emails approved", value: numberFormat(scale(m.emailsApproved)), note: "Founder-reviewed & approved" },
    { key: "emailsSent", label: "Emails sent", value: numberFormat(scale(m.emailsSent)), note: "Delivered outreach volume" },
    { key: "repliesRecorded", label: "Replies recorded", value: numberFormat(scale(m.repliesRecorded)), note: "Prospect responses logged" },
    {
      key: "aiConsumption",
      label: "AI API consumption & cost",
      value: `${numberFormat(scale(m.aiRequests))} req · ${currency.format(scaleFloat(m.aiCost))}`,
      note: `${(scale(m.aiTokens) / 1000).toFixed(1)}K tokens · ${scale(m.aiFailedRequests)} failed · ${m.aiProvider}`,
    },
    {
      key: "hunterCredits",
      label: "Hunter credit consumption",
      value: numberFormat(scale(m.hunterCredits)),
      note: "Credits consumed in selected date range",
    },
  ];

  const filteredMetrics = filterSearchRecords(activityMetrics, search, (item) => [
    item.label,
    item.value,
    item.note,
  ]);

  const filteredBreakdown = filterSearchRecords(report.breakdown, search, (item) => [
    item.label,
    item.completed ? "Completed" : "Incomplete",
    `${item.earnedPoints}/${item.points}`,
  ]);

  const filteredUsers = filterSearchRecords(report.users, search, (u) => [
    u.id,
    u.name,
    u.email,
    u.workspaceRole,
    u.status,
  ]);

  const handleExport = () => {
    downloadCsv(
      [
        {
          Startup: report.name,
          "Startup ID": report.id,
          Founder: report.founder,
          Plan: report.plan,
          Status: report.status,
          "Date Range": range,
          "Engagement Score": `${report.score}/100`,
          "Engagement Level": report.tier,
          "Inactive Flag": report.inactivity.inactive ? "Yes" : "No",
          "Upgrade Opportunity": report.upgrade.eligible ? report.upgrade.recommendedPlan : "None",
          "ICPs Created": m.icpsCreated,
          "Prospects Researched": scale(m.prospectsResearched),
          "Decision-Makers Identified": scale(m.decisionMakersIdentified),
          "Prospects Qualified": scale(m.prospectsQualified),
          "Buying Signals Analysed": scale(m.buyingSignalsAnalyzed),
          "Email Drafts Generated": scale(m.emailDraftsGenerated),
          "Emails Approved": scale(m.emailsApproved),
          "Emails Sent": scale(m.emailsSent),
          "Replies Recorded": scale(m.repliesRecorded),
          "AI Requests": scale(m.aiRequests),
          "AI Tokens": scale(m.aiTokens),
          "AI Cost (USD)": scaleFloat(m.aiCost),
          "Hunter Credits": scale(m.hunterCredits),
        },
      ],
      `bluecode-startup-report-${report.id}.csv`,
    );
    if (typeof onAuditAction === "function") {
      onAuditAction(`Exported activity report for ${report.name} (${report.id})`, "Startup Management", "Info");
    }
  };

  return (
    <>
      <div className="admin-profile-topbar">
        <Button variant="outline" size="sm" onClick={onBack}>
          <ArrowLeft aria-hidden="true" /> {backLabel}
        </Button>
        <div className="admin-heading-action">
          <DateRangeControls
            range={range}
            setRange={setRange}
            customStart={customStart}
            setCustomStart={setCustomStart}
            customEnd={customEnd}
            setCustomEnd={setCustomEnd}
          />
          <Button variant="outline" size="sm" onClick={handleExport}>
            <Download aria-hidden="true" /> Export report
          </Button>
        </div>
      </div>

      <section className="admin-panel">
        <div className="admin-panel-heading">
          <div className="admin-company-cell">
            <span className="admin-company-mark">{report.name.slice(0, 1)}</span>
            <span>
              <h2 style={{ margin: 0 }}>{report.name} · Activity & Engagement Report</h2>
              <p style={{ margin: "4px 0 0" }}>
                ID <code>{report.id}</code> · Founder {report.founder} · Plan <strong>{report.plan}</strong> · Last active {report.lastActive}
              </p>
            </span>
          </div>
          <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", alignItems: "center" }}>
            <StatusPill>{report.status}</StatusPill>
            <StatusPill>{report.tier}</StatusPill>
            {report.inactivity.inactive ? <StatusPill>At risk</StatusPill> : null}
          </div>
        </div>

        <div className="admin-metric-grid">
          <article className="admin-metric">
            <div className="admin-metric-icon"><Target aria-hidden="true" /></div>
            <div className="admin-metric-copy">
              <p>Engagement score</p>
              <strong>{report.score} / 100</strong>
              <span>Level: {report.tier} (computed from sample activity)</span>
            </div>
          </article>
          <article className="admin-metric">
            <div className="admin-metric-icon tone-teal"><Clock3 aria-hidden="true" /></div>
            <div className="admin-metric-copy">
              <p>Activity status</p>
              <strong>{report.inactivity.inactive ? "Inactive" : "Active"}</strong>
              <span>{report.inactivity.inactive ? report.inactivity.reason : `Last seen ${report.lastActive}`}</span>
            </div>
          </article>
          <article className="admin-metric">
            <div className="admin-metric-icon tone-green"><ArrowUpRight aria-hidden="true" /></div>
            <div className="admin-metric-copy">
              <p>Upgrade opportunity</p>
              <strong>{report.upgrade.eligible ? report.upgrade.recommendedPlan : "Aligned"}</strong>
              <span>{report.upgrade.eligible ? report.upgrade.reason : "Usage fits current plan tier"}</span>
            </div>
          </article>
          <article className="admin-metric">
            <div className="admin-metric-icon tone-amber"><CircleDollarSign aria-hidden="true" /></div>
            <div className="admin-metric-copy">
              <p>AI & Hunter spend</p>
              <strong>{currency.format(scaleFloat(m.aiCost))}</strong>
              <span>{numberFormat(scale(m.hunterCredits))} Hunter credits · {numberFormat(scale(m.aiRequests))} AI req</span>
            </div>
          </article>
        </div>
      </section>

      <div className="admin-content-grid overview-grid">
        <section className="admin-panel">
          <div className="admin-panel-heading">
            <div>
              <h2>Detailed startup activity metrics</h2>
              <p>Complete activity breakdown for {report.name} ({range === "custom" ? `${customStart} to ${customEnd}` : `last ${range}`}).</p>
            </div>
            <span className="admin-demo-badge">DEMO DATA</span>
          </div>
          <div className="admin-table-scroll">
            <table className="admin-data-table">
              <thead>
                <tr>
                  <th>Metric</th>
                  <th>Value</th>
                  <th>Details</th>
                </tr>
              </thead>
              <tbody>
                {filteredMetrics.map((item) => (
                  <tr key={item.key}>
                    <td><strong>{item.label}</strong></td>
                    <td><strong>{item.value}</strong></td>
                    <td>{item.note}</td>
                  </tr>
                ))}
                {!filteredMetrics.length ? (
                  <tr><td colSpan={3} className="admin-empty-cell">No results found.</td></tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </section>

        <section className="admin-panel">
          <div className="admin-panel-heading">
            <div>
              <h2>Engagement score breakdown</h2>
              <p>Weighted 100-point rubric derived from workspace activity.</p>
            </div>
            <span className="admin-score-value">{report.score}/100</span>
          </div>
          <div className="admin-table-scroll">
            <table className="admin-data-table">
              <thead>
                <tr>
                  <th>Activity criterion</th>
                  <th>Status</th>
                  <th>Points</th>
                </tr>
              </thead>
              <tbody>
                {filteredBreakdown.map((item) => (
                  <tr key={item.key}>
                    <td><strong>{item.label}</strong></td>
                    <td>
                      <StatusPill>{item.completed ? "Active" : "At risk"}</StatusPill>
                    </td>
                    <td>
                      <strong>{item.earnedPoints}</strong> / {item.points}
                    </td>
                  </tr>
                ))}
                {!filteredBreakdown.length ? (
                  <tr><td colSpan={3} className="admin-empty-cell">No results found.</td></tr>
                ) : null}
              </tbody>
            </table>
          </div>
          <p className="admin-footnote">
            Illustrative scores are calculated from sample workspace activity records and are not live customer scores.
          </p>
        </section>
      </div>

      <section className="admin-panel">
        <div className="admin-panel-heading">
          <div>
            <h2>Tenant-isolated workspace members ({filteredUsers.length})</h2>
            <p>Strictly scoped to startup ID <code>{report.id}</code>. Customer prospect lists and email message bodies are never exposed.</p>
          </div>
          <span className="admin-scope-badge scope-individual">TENANT ISOLATED</span>
        </div>
        <div className="admin-table-scroll">
          <table className="admin-data-table">
            <thead>
              <tr>
                <th>User ID</th>
                <th>Member</th>
                <th>Role</th>
                <th>Status</th>
                <th>Last login</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user) => (
                <tr key={user.id}>
                  <td><code>{user.id}</code></td>
                  <td>
                    <div className="admin-company-cell">
                      <span className="admin-company-mark">{user.name.slice(0, 1)}</span>
                      <span><strong>{user.name}</strong><small>{user.email}</small></span>
                    </div>
                  </td>
                  <td>{user.workspaceRole}</td>
                  <td><StatusPill>{user.status}</StatusPill></td>
                  <td>{user.lastLoginDisplay}</td>
                </tr>
              ))}
              {!filteredUsers.length ? (
                <tr><td colSpan={5} className="admin-empty-cell">No results found.</td></tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
