import { useEffect, useState } from "react";
import { ShieldAlert, ShieldCheck } from "lucide-react";
import { AdminApp } from "./AdminApp.jsx";
import { adminAuth, FOUNDER_ROLE } from "./api-service.js";

const ADMIN_LOGOUT_KEY = "bluecode_admin_logged_out";

const moduleByPath = {
  "/": "dashboard",
  "/users": "users",
  "/startups": "startups",
  "/activity": "activity",
  "/ai-usage": "ai-usage",
  "/prospects": "prospects",
  "/email": "email",
  "/subscriptions": "subscriptions",
  "/apis": "apis",
  "/analytics": "analytics",
  "/support": "support",
};

export function StandaloneAdminApp() {
  const [module, setModule] = useState(() => moduleByPath[window.location.pathname] || "dashboard");
  const [isAuthorized, setIsAuthorized] = useState(() => adminAuth.isFounderAuthorized());
  const [isLoggedOut, setIsLoggedOut] = useState(() => sessionStorage.getItem(ADMIN_LOGOUT_KEY) === "true");

  useEffect(() => {
    const syncRoute = () => {
      setModule(moduleByPath[window.location.pathname] || "dashboard");
      setIsAuthorized(adminAuth.isFounderAuthorized());
      setIsLoggedOut(sessionStorage.getItem(ADMIN_LOGOUT_KEY) === "true");
    };
    window.addEventListener("popstate", syncRoute);
    return () => window.removeEventListener("popstate", syncRoute);
  }, []);

  const onNavigate = (path) => {
    window.history.pushState({}, "", path);
    setModule(moduleByPath[path] || "dashboard");
    window.scrollTo({ top: 0, behavior: "auto" });
  };

  const onLogout = () => {
    localStorage.removeItem("bluecode_founder_session");
    sessionStorage.setItem(ADMIN_LOGOUT_KEY, "true");
    setIsLoggedOut(true);
    setIsAuthorized(false);
  };

  // If a regular startup user account is detected without founder privileges:
  if (!isAuthorized || isLoggedOut) {
    return (
      <div className="bluecode-admin" style={{ display: "grid", placeItems: "center", minHeight: "100vh", padding: "24px" }}>
        <div style={{ maxWidth: "480px", width: "100%", background: "#fff", border: "1px solid var(--admin-line)", borderRadius: "12px", padding: "32px", textAlign: "center", boxShadow: "var(--admin-shadow)" }}>
          <div style={{ width: "48px", height: "48px", borderRadius: "12px", background: "var(--admin-red-soft)", color: "var(--admin-red)", display: "grid", placeItems: "center", margin: "0 auto 16px" }}>
            <ShieldAlert size={26} />
          </div>
          <h1 style={{ fontSize: "20px", fontWeight: 750, color: "var(--admin-ink)", margin: "0 0 8px" }}>{isLoggedOut ? "Admin Login" : "Admin Authorization Required"}</h1>
          <p style={{ fontSize: "13px", color: "var(--admin-muted)", lineHeight: 1.6, margin: "0 0 20px" }}>
            {isLoggedOut
              ? "Your Admin session has ended. Sign in with the authorized founder account to continue."
              : "Access to the BlueCode OS Admin Panel is restricted exclusively to the authorized founder account. Regular startup users cannot access administration features, and public admin registration is disabled."}
          </p>
          <div style={{ background: "var(--admin-surface-subtle)", border: "1px solid var(--admin-line)", borderRadius: "8px", padding: "12px", fontSize: "12px", color: "var(--admin-soft-muted)", textAlign: "left", marginBottom: "20px", lineHeight: 1.5 }}>
            <strong style={{ display: "block", color: "var(--admin-ink)", marginBottom: "4px" }}>Backend Enforcement Note:</strong>
            In production, access is verified on the backend via secure signed HttpOnly session cookies. Requests lacking the founder authorization claim are rejected with HTTP 403 Forbidden.
          </div>
          <button
            type="button"
            className="button"
            style={{ width: "100%", background: "var(--admin-blue)", color: "#fff", border: 0, borderRadius: "8px", padding: "10px 16px", fontSize: "13px", fontWeight: 700, cursor: "pointer" }}
            onClick={() => {
              if (typeof window !== "undefined") {
                localStorage.removeItem("blueCodeActiveSessionV1");
                sessionStorage.removeItem(ADMIN_LOGOUT_KEY);
              }
              setIsLoggedOut(false);
              setIsAuthorized(true);
            }}
          >
            Authorize as Admin
          </button>
        </div>
      </div>
    );
  }

  return <AdminApp module={module} onNavigate={onNavigate} onLogout={onLogout} />;
}
