export const engagementWeights = {
  createdIcp: 10,
  researchedProspects: 15,
  discoveredDecisionMakers: 15,
  generatedEmailDrafts: 15,
  approvedAndSentEmails: 20,
  recordedReplies: 15,
  returnedToPlatform: 10,
};

export const engagementCriteria = [
  { key: "createdIcp", label: "Created an ICP", points: engagementWeights.createdIcp },
  { key: "researchedProspects", label: "Researched prospects", points: engagementWeights.researchedProspects },
  { key: "discoveredDecisionMakers", label: "Used decision-maker discovery", points: engagementWeights.discoveredDecisionMakers },
  { key: "generatedEmailDrafts", label: "Generated email drafts", points: engagementWeights.generatedEmailDrafts },
  { key: "approvedAndSentEmails", label: "Approved and sent emails", points: engagementWeights.approvedAndSentEmails },
  { key: "recordedReplies", label: "Recorded prospect replies", points: engagementWeights.recordedReplies },
  { key: "returnedToPlatform", label: "Returned and used the platform again", points: engagementWeights.returnedToPlatform },
];

export const engagementThresholds = {
  atRiskBelow: 40,
  engagedFrom: 70,
};

/**
 * Derives the 7 engagement behavior booleans from actual available activity data
 * (users, prospect activity, email activity, and session activity), falling back
 * to startup.engagement flags only when activity records are absent.
 */
export function deriveEngagementBehaviors({
  startup = {},
  users = [],
  prospectRecord = null,
  emailRecord = null,
  activityRecord = null,
} = {}) {
  const fallback = startup.engagement || {};
  const hasActivitySources = Boolean(
    users.length || prospectRecord || emailRecord || activityRecord,
  );

  if (!hasActivitySources) {
    return {
      createdIcp: Boolean(fallback.createdIcp),
      researchedProspects: Boolean(fallback.researchedProspects),
      discoveredDecisionMakers: Boolean(fallback.discoveredDecisionMakers),
      generatedEmailDrafts: Boolean(fallback.generatedEmailDrafts),
      approvedAndSentEmails: Boolean(fallback.approvedAndSentEmails),
      recordedReplies: Boolean(fallback.recordedReplies),
      returnedToPlatform: Boolean(fallback.returnedToPlatform),
    };
  }

  const totalIcps = users.reduce((sum, u) => sum + (u.featureUsage?.icpsCreated || 0), 0);
  const totalResearched =
    prospectRecord?.researched ??
    users.reduce((sum, u) => sum + (u.featureUsage?.prospectsResearched || 0), 0);
  const totalDecisionMakers =
    prospectRecord?.decisionMakers ??
    users.reduce((sum, u) => sum + (u.featureUsage?.decisionMakerSearches || 0), 0);
  const totalDrafts =
    emailRecord?.drafts ??
    users.reduce((sum, u) => sum + (u.featureUsage?.emailsDrafted || 0), 0);
  const totalApproved = emailRecord?.approved ?? 0;
  const totalSent =
    emailRecord?.sent ??
    users.reduce((sum, u) => sum + (u.featureUsage?.emailsSent || 0), 0);
  const totalReplies =
    emailRecord?.replies ??
    users.reduce((sum, u) => sum + (u.salesOutreach?.deliveryStats?.replies || 0), 0);

  const activeDays = activityRecord?.activeDays ?? 0;
  const sessions = activityRecord?.sessions ?? 0;
  const totalLogins = users.reduce((sum, u) => sum + (u.loginHistory?.length || 0), 0);

  return {
    createdIcp: totalIcps > 0 || Boolean(fallback.createdIcp),
    researchedProspects: totalResearched > 0,
    discoveredDecisionMakers: totalDecisionMakers > 0,
    generatedEmailDrafts: totalDrafts > 0,
    approvedAndSentEmails: (totalApproved > 0 && totalSent > 0) || totalSent > 0,
    recordedReplies: totalReplies > 0,
    returnedToPlatform: activeDays > 1 || sessions > 2 || totalLogins > 1,
  };
}

export function calculateEngagementScore(events = {}) {
  const total = Object.entries(engagementWeights).reduce(
    (score, [behavior, points]) => score + (events[behavior] ? points : 0),
    0,
  );

  return Math.min(100, total);
}

export function getEngagementBreakdown(events = {}) {
  return engagementCriteria.map((criterion) => {
    const completed = Boolean(events[criterion.key]);
    return {
      ...criterion,
      completed,
      earnedPoints: completed ? criterion.points : 0,
    };
  });
}

export function getEngagementTier(score, thresholds = engagementThresholds) {
  if (score < thresholds.atRiskBelow) return "At risk";
  if (score >= thresholds.engagedFrom) return "Engaged";
  return "Developing";
}

function parseDaysAgo(label) {
  if (!label || typeof label !== "string") return null;
  const lower = label.toLowerCase();
  if (lower.includes("today")) return 0;
  if (lower.includes("yesterday")) return 1;
  const match = lower.match(/(\d+)\s+day/);
  return match ? Number(match[1]) : null;
}

/**
 * Identifies inactive customers based on days since last activity (default >= 14 days)
 * or explicit "At risk" status with no return sessions.
 */
export function isInactiveStartup(startup = {}, activityRecord = null, inactiveDaysThreshold = 14) {
  const days = parseDaysAgo(activityRecord?.lastSeen || startup.lastActive);
  if (days !== null && days >= inactiveDaysThreshold) {
    return {
      inactive: true,
      daysSinceActive: days,
      reason: `No platform activity for ${days} days`,
    };
  }
  if (startup.status === "At risk" && (activityRecord?.activeDays ?? 1) <= 1) {
    return {
      inactive: true,
      daysSinceActive: days,
      reason: "Single active day and flagged at risk",
    };
  }
  return {
    inactive: false,
    daysSinceActive: days,
    reason: null,
  };
}

/**
 * Identifies potential upgrade opportunities based on plan tier, engagement score,
 * and AI/prospect usage relative to current plan limits.
 */
export function getUpgradeOpportunity({
  startup = {},
  subscription = null,
  score = 0,
  aiRecord = null,
} = {}) {
  const plan = subscription?.plan || startup.plan || "Starter";
  const status = subscription?.status || startup.status || "Active";
  const budgetLimit = aiRecord?.budgetLimit || 0;
  const aiSpend = aiRecord?.cost ?? startup.aiSpend ?? 0;
  const budgetUtilization = budgetLimit > 0 ? aiSpend / budgetLimit : 0;

  if (status === "Trial" && score >= 60) {
    return {
      eligible: true,
      recommendedPlan: plan === "Pro" ? "Pro (Paid)" : "Growth",
      reason: `High trial engagement (${score}/100) — ready to convert`,
    };
  }
  if (plan === "Starter" && (score >= 50 || budgetUtilization >= 0.6)) {
    return {
      eligible: true,
      recommendedPlan: "Growth",
      reason:
        budgetUtilization >= 0.6
          ? `AI spend at ${Math.round(budgetUtilization * 100)}% of Starter budget`
          : `Strong Starter engagement (${score}/100)`,
    };
  }
  if (plan === "Growth" && (score >= 70 || budgetUtilization >= 0.7)) {
    return {
      eligible: true,
      recommendedPlan: "Pro",
      reason:
        budgetUtilization >= 0.7
          ? `AI spend at ${Math.round(budgetUtilization * 100)}% of Growth budget`
          : `High Growth engagement (${score}/100)`,
    };
  }

  return {
    eligible: false,
    recommendedPlan: null,
    reason: null,
  };
}
