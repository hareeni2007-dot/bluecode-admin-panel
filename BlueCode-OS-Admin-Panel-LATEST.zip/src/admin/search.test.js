import { describe, expect, it } from "vitest";
import { adminApi } from "./api-service.js";
import { filterSearchRecords, getModuleSearchQuery } from "./search.js";

const users = adminApi.listUsers();
const maya = users.find((user) => user.email === "maya@northstarlabs.io");

const filterUsers = (query, status = "All statuses", plan = "All plans") =>
  filterSearchRecords(
    users,
    query,
    (user) => [
      user.name,
      user.email,
      user.id,
      user.startupName,
      user.startupPlan,
      user.status,
    ],
    (user) => (status === "All statuses" || user.status === status)
      && (plan === "All plans" || user.startupPlan === plan),
  );

describe("module search", () => {
  it.each([
    ["a user's name", "Maya Rao"],
    ["an email address", "MAYA@NORTHSTARLABS.IO"],
    ["a user ID", "usr-101"],
    ["a subscription plan", "Growth"],
    ["a status", "Active"],
  ])("matches %s", (_description, query) => {
    expect(filterUsers(query)).toContain(maya);
  });

  it("combines search with the existing status and plan filters", () => {
    expect(filterUsers("maya@", "Active", "Growth")).toEqual([maya]);
    expect(filterUsers("maya@", "Active", "Pro")).toEqual([]);
  });

  it("returns no records when nothing matches", () => {
    expect(filterUsers("no-such-record")).toEqual([]);
  });

  it("restores records when the search is cleared", () => {
    expect(filterUsers("Maya")).toEqual([maya]);
    expect(filterUsers("   ")).toEqual(users);
  });

  it("does not carry a previous module's search into the next module", () => {
    const searchState = { module: "users", query: "Maya" };
    expect(getModuleSearchQuery("users", searchState)).toBe("Maya");
    expect(getModuleSearchQuery("ai-usage", searchState)).toBe("");
  });

  it("matches activity descriptions case-insensitively", () => {
    const activity = adminApi.listUserActivity();
    expect(
      filterSearchRecords(activity, "RESEARCH", (row) => [
        row.id,
        row.founder,
        row.startup,
        row.mostUsedFeature,
      ]),
    ).toHaveLength(activity.filter((row) => row.mostUsedFeature.toLowerCase().includes("research")).length);
  });
});
