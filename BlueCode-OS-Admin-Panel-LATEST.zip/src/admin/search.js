export function filterSearchRecords(records, query, getSearchValues, predicate = () => true) {
  const normalizedQuery = String(query ?? "").trim().toLowerCase();

  return records.filter((record) => {
    if (!predicate(record)) return false;
    if (!normalizedQuery) return true;

    return getSearchValues(record).some((value) =>
      String(value ?? "").toLowerCase().includes(normalizedQuery),
    );
  });
}

export function getModuleSearchQuery(module, searchState) {
  return searchState?.module === module ? searchState.query : "";
}
