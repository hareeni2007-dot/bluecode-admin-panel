import { describe, expect, it } from "vitest";
import {
  calculateEngagementScore,
  deriveEngagementBehaviors,
  getEngagementBreakdown,
  getEngagementTier,
  getUpgradeOpportunity,
  isInactiveStartup,
} from "./engagement.js";
import { FOUNDER_ROLE, verifyFounderAuthorization, adminAuth, adminApi, getRangeFactor } from "./api-service.js";

describe("engagement scoring from the requirements PDF", () => {
  it("awards 10 points for creating an ICP", () => {
    expect(calculateEngagementScore({ createdIcp: true })).toBe(10);
  });

  it("awards 15 points for researching prospects", () => {
    expect(calculateEngagementScore({ researchedProspects: true })).toBe(15);
  });

  it("awards 15 points for decision-maker discovery", () => {
    expect(calculateEngagementScore({ discoveredDecisionMakers: true })).toBe(15);
  });

  it("awards 15 points for generating email drafts", () => {
    expect(calculateEngagementScore({ generatedEmailDrafts: true })).toBe(15);
  });

  it("awards 20 points for approved and sent emails", () => {
    expect(calculateEngagementScore({ approvedAndSentEmails: true })).toBe(20);
  });

  it("awards 15 points for recording prospect replies", () => {
    expect(calculateEngagementScore({ recordedReplies: true })).toBe(15);
  });

  it("awards 10 points for returning to use the platform", () => {
    expect(calculateEngagementScore({ returnedToPlatform: true })).toBe(10);
  });

  it("caps the score at the required maximum of 100", () => {
    expect(calculateEngagementScore({
      createdIcp: true,
      researchedProspects: true,
      discoveredDecisionMakers: true,
      generatedEmailDrafts: true,
      approvedAndSentEmails: true,
      recordedReplies: true,
      returnedToPlatform: true,
    })).toBe(100);
  });

  it("uses configurable customer engagement bands", () => {
    expect(getEngagementTier(39)).toBe("At risk");
    expect(getEngagementTier(40)).toBe("Developing");
    expect(getEngagementTier(69)).toBe("Developing");
    expect(getEngagementTier(70)).toBe("Engaged");
  });
});

describe("founder-only admin authorization & platform access", () => {
  it("enforces Founder Admin as the single authorized role", () => {
    expect(FOUNDER_ROLE).toBe("Founder Admin");
    expect(adminAuth.getRole()).toBe("Founder Admin");
    expect(adminAuth.getCurrentFounder().name).toBe("Admin");
  });

  it("authorizes valid founder account credentials", () => {
    const result = verifyFounderAuthorization({
      email: "founder@bluecode.internal",
      role: "Founder Admin",
    });
    expect(result.authorized).toBe(true);
  });

  it("rejects regular startup accounts without founder credentials", () => {
    const startupUser = {
      email: "user@startup.io",
      role: "startup_user",
    };
    const result = verifyFounderAuthorization(startupUser);
    expect(result.authorized).toBe(false);
    expect(result.reason).toContain("Regular startup accounts cannot access");
  });

  it("rejects unauthenticated requests", () => {
    const result = verifyFounderAuthorization(null);
    expect(result.authorized).toBe(false);
  });

  it("provides Founder Admin access to all platform summary and list APIs", () => {
    expect(adminApi.getDashboardSummary()).toBeDefined();
    expect(adminApi.listStartups().length).toBeGreaterThan(0);
    expect(adminApi.listUserActivity().length).toBeGreaterThan(0);
    expect(adminApi.listAiUsage().length).toBeGreaterThan(0);
    expect(adminApi.listProspectActivity().length).toBeGreaterThan(0);
    expect(adminApi.listEmailActivity().length).toBeGreaterThan(0);
    expect(adminApi.listSubscriptions().length).toBeGreaterThan(0);
    expect(adminApi.listApiUsage().length).toBeGreaterThan(0);
    expect(adminApi.listAuditEvents().length).toBeGreaterThan(0);
    expect(adminApi.listFeatureUsage().length).toBeGreaterThan(0);
    expect(adminApi.getUsageTrend("30d").length).toBeGreaterThan(0);
  });

  it("joins registered users with startup and subscription records without duplicating data", () => {
    const users = adminApi.listUsers();
    expect(users.length).toBeGreaterThan(0);
    const first = adminApi.getUserById(users[0].id);
    expect(first).not.toBeNull();
    expect(first.startupName).toBe(first.startup.name);
    expect(first.startupPlan).toBe(first.subscription.plan);
    expect(first.featureUsage).toBeDefined();
    expect(first.aiMonitoring).toBeDefined();
    expect(first.salesOutreach).toBeDefined();
    expect(first.loginHistory).toBeDefined();
  });

  it("supports Founder status overrides for suspend and reactivate", () => {
    const suspended = adminApi.getUserById("usr-101", { "usr-101": "Suspended" });
    expect(suspended.status).toBe("Suspended");
    const reactivated = adminApi.getUserById("usr-101", { "usr-101": "Active" });
    expect(reactivated.status).toBe("Active");
  });

  it("computes date range factors for 7d, 30d, 90d, and custom windows", () => {
    expect(getRangeFactor("7d")).toBe(0.28);
    expect(getRangeFactor("30d")).toBe(1);
    expect(getRangeFactor("90d")).toBe(2.75);
    expect(getRangeFactor("custom", "2026-11-01", "2026-11-15")).toBe(0.5);
  });

  it("derives engagement behaviors from activity data and builds a 7-item breakdown", () => {
    const behaviors = deriveEngagementBehaviors({
      users: [{ featureUsage: { icpsCreated: 2 }, loginHistory: [{}, {}] }],
      prospectRecord: { researched: 40, decisionMakers: 12 },
      emailRecord: { drafts: 10, approved: 5, sent: 4, replies: 0 },
      activityRecord: { sessions: 5, activeDays: 3 },
    });
    expect(behaviors).toEqual({
      createdIcp: true,
      researchedProspects: true,
      discoveredDecisionMakers: true,
      generatedEmailDrafts: true,
      approvedAndSentEmails: true,
      recordedReplies: false,
      returnedToPlatform: true,
    });
    const score = calculateEngagementScore(behaviors);
    expect(score).toBe(85);
    const breakdown = getEngagementBreakdown(behaviors);
    expect(breakdown).toHaveLength(7);
    expect(breakdown.find((item) => item.key === "recordedReplies").earnedPoints).toBe(0);
  });

  it("identifies inactive customers and upgrade opportunities", () => {
    const inactive = isInactiveStartup({ status: "At risk", lastActive: "18 days ago" }, { activeDays: 1, lastSeen: "18 days ago" });
    expect(inactive.inactive).toBe(true);
    expect(inactive.daysSinceActive).toBe(18);

    const active = isInactiveStartup({ status: "Active", lastActive: "Today" }, { activeDays: 12, lastSeen: "Today, 10:42 AM" });
    expect(active.inactive).toBe(false);

    const trialUpgrade = getUpgradeOpportunity({ startup: { plan: "Growth", status: "Trial" }, score: 85 });
    expect(trialUpgrade.eligible).toBe(true);
    expect(trialUpgrade.recommendedPlan).toBe("Growth");
  });

  it("builds a complete tenant-isolated startup activity report", () => {
    const report = adminApi.getStartupReport("st-01");
    expect(report).not.toBeNull();
    expect(report.score).toBe(100);
    expect(report.breakdown).toHaveLength(7);
    expect(report.users.every((u) => u.startupId === "st-01")).toBe(true);
    expect(report.metrics.icpsCreated).toBeGreaterThan(0);
    expect(report.metrics.prospectsResearched).toBe(240);
    expect(report.metrics.decisionMakersIdentified).toBe(110);
    expect(report.metrics.prospectsQualified).toBe(180);
    expect(report.metrics.buyingSignalsAnalyzed).toBe(120);
    expect(report.metrics.emailDraftsGenerated).toBe(110);
    expect(report.metrics.emailsApproved).toBe(75);
    expect(report.metrics.emailsSent).toBe(65);
    expect(report.metrics.repliesRecorded).toBe(12);
    expect(report.metrics.aiCost).toBe(86.4);
    expect(report.metrics.hunterCredits).toBe(240);
  });
});