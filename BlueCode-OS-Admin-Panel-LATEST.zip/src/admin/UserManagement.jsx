import { useMemo, useState } from "react";
import {
  Activity,
  ArrowLeft,
  CalendarDays,
  CheckCircle2,
  CreditCard,
  Download,
  Eye,
  KeyRound,
  Mail,
  Network,
  Search,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Target,
  UserCheck,
  UserX,
  Users,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { adminApi, downloadCsv, getRangeFactor } from "./api-service.js";
import { filterSearchRecords } from "./search.js";

const currency = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

function numberFormat(value) {
  return new Intl.NumberFormat("en-US").format(value);
}

function StatusPill({ children }) {
  const tone = String(children).toLowerCase().replaceAll(" ", "-").replaceAll("·", "");
  return <span className={`admin-status status-${tone}`}>{children}</span>;
}

export function DateRangeControls({ range, setRange, customStart, setCustomStart, customEnd, setCustomEnd }) {
  return (
    <div className="admin-date-controls">
      <label className="admin-range-select">
        <CalendarDays aria-hidden="true" />
        <select aria-label="Reporting period" value={range} onChange={(event) => setRange(event.target.value)}>
          <option value="7d">Last 7 days</option>
          <option value="30d">Last 30 days</option>
          <option value="90d">Last 90 days</option>
          <option value="custom">Custom range</option>
        </select>
      </label>
      {range === "custom" ? (
        <div className="admin-custom-dates">
          <input type="date" aria-label="Start date" value={customStart} onChange={(e) => setCustomStart(e.target.value)} />
          <span>to</span>
          <input type="date" aria-label="End date" value={customEnd} onChange={(e) => setCustomEnd(e.target.value)} />
        </div>
      ) : null}
    </div>
  );
}

export function UsersPage({
  search,
  statusFilter,
  setStatusFilter,
  userStatusOverrides,
  onSelectUser,
}) {
  const [planFilter, setPlanFilter] = useState("All plans");
  const users = useMemo(() => adminApi.listUsers(userStatusOverrides), [userStatusOverrides]);

  const filteredUsers = useMemo(() => {
    return filterSearchRecords(
      users,
      search,
      (user) => [
        user.name,
        user.email,
        user.id,
        user.startupName,
        user.startupPlan,
        user.status,
        user.startupStatus,
        user.workspaceRole,
        user.registrationDate,
        user.lastLoginDisplay,
      ],
      (user) => (statusFilter === "All statuses" || user.status === statusFilter)
        && (planFilter === "All plans" || user.startupPlan === planFilter),
    );
  }, [users, search, statusFilter, planFilter]);

  const activeCount = users.filter((u) => u.status === "Active").length;
  const trialCount = users.filter((u) => u.status === "Trial").length;
  const suspendedCount = users.filter((u) => u.status === "Suspended").length;

  const exportRows = filteredUsers.map((u) => ({
    "User ID": u.id,
    Name: u.name,
    Email: u.email,
    "Startup / Company": u.startupName,
    "Registration Date": u.registrationDate,
    "Last Login": u.lastLoginDisplay,
    Plan: u.startupPlan,
    Status: u.status,
  }));

  return (
    <>
      <div className="admin-page-heading">
        <div>
          <p className="admin-eyebrow">FOUNDER USER DIRECTORY</p>
          <h1>User management</h1>
          <p className="admin-page-description">
            Inspect registered users, monitor individual feature usage, and manage account status across all workspaces.
          </p>
        </div>
        <div className="admin-heading-action">
          <Button variant="outline" onClick={() => downloadCsv(exportRows, "bluecode-users.csv")} disabled={!exportRows.length}>
            <Download aria-hidden="true" /> Export users
          </Button>
        </div>
      </div>

      <div className="admin-metric-grid">
        <article className="admin-metric">
          <div className="admin-metric-icon"><Users aria-hidden="true" /></div>
          <div className="admin-metric-copy">
            <p>Registered users</p>
            <strong>{users.length}</strong>
            <span>Sample directory · DEMO DATA</span>
          </div>
        </article>
        <article className="admin-metric">
          <div className="admin-metric-icon tone-green"><UserCheck aria-hidden="true" /></div>
          <div className="admin-metric-copy">
            <p>Active accounts</p>
            <strong>{activeCount}</strong>
            <span>Verified workspace access</span>
          </div>
        </article>
        <article className="admin-metric">
          <div className="admin-metric-icon tone-teal"><Sparkles aria-hidden="true" /></div>
          <div className="admin-metric-copy">
            <p>Trial accounts</p>
            <strong>{trialCount}</strong>
            <span>Evaluating BlueCode-OS</span>
          </div>
        </article>
        <article className="admin-metric">
          <div className="admin-metric-icon tone-amber"><UserX aria-hidden="true" /></div>
          <div className="admin-metric-copy">
            <p>Suspended accounts</p>
            <strong>{suspendedCount}</strong>
            <span>Founder-restricted access</span>
          </div>
        </article>
      </div>

      <section className="admin-panel">
        <div className="admin-panel-heading">
          <div>
            <h2>Registered users</h2>
            <p>Click View Details on any user to inspect their individual profile, feature usage, AI/API logs, outreach, and billing.</p>
          </div>
          <span className="admin-demo-badge">DEMO DATA</span>
        </div>

        <div className="admin-table-tools">
          <div className="admin-filter-group">
            <label className="admin-filter-label">
              <span>Status</span>
              <span className="admin-select-wrap">
                <select aria-label="Filter users by status" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                  <option value="All statuses">All statuses</option>
                  <option value="Active">Active</option>
                  <option value="Trial">Trial</option>
                  <option value="At risk">At risk</option>
                  <option value="Suspended">Suspended</option>
                </select>
              </span>
            </label>
            <label className="admin-filter-label">
              <span>Plan</span>
              <span className="admin-select-wrap">
                <select aria-label="Filter users by plan" value={planFilter} onChange={(e) => setPlanFilter(e.target.value)}>
                  <option value="All plans">All plans</option>
                  <option value="Starter">Starter</option>
                  <option value="Growth">Growth</option>
                  <option value="Pro">Pro</option>
                  <option value="Trial">Trial</option>
                </select>
              </span>
            </label>
          </div>
          <span className="admin-table-count">{filteredUsers.length} users shown</span>
        </div>

        <div className="admin-table-frame">
          <div className="admin-table-scroll">
            <table className="admin-data-table">
              <thead>
                <tr>
                  <th scope="col">User</th>
                  <th scope="col">User ID</th>
                  <th scope="col">Startup / Company</th>
                  <th scope="col">Registered</th>
                  <th scope="col">Last login</th>
                  <th scope="col">Plan</th>
                  <th scope="col">Status</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map((user) => (
                  <tr key={user.id}>
                    <td>
                      <div className="admin-company-cell">
                        <span className="admin-company-mark">{user.name.slice(0, 1)}</span>
                        <span>
                          <strong>{user.name}</strong>
                          <small>{user.email}</small>
                        </span>
                      </div>
                    </td>
                    <td><code>{user.id}</code></td>
                    <td>
                      <div className="admin-company-cell">
                        <span>
                          <strong>{user.startupName}</strong>
                          <small>{user.workspaceRole}</small>
                        </span>
                      </div>
                    </td>
                    <td>{user.registrationDate}</td>
                    <td>{user.lastLoginDisplay}</td>
                    <td><span className="admin-plan-label">{user.startupPlan}</span></td>
                    <td><StatusPill>{user.status}</StatusPill></td>
                    <td>
                      <Button variant="outline" size="sm" onClick={() => onSelectUser(user.id)}>
                        <Eye aria-hidden="true" /> View Details
                      </Button>
                    </td>
                  </tr>
                ))}
                {!filteredUsers.length ? (
                  <tr>
                    <td colSpan={8} className="admin-empty-cell">No results found.</td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </>
  );
}

export function UserProfileView({
  userId,
  search = "",
  userStatusOverrides,
  onBack,
  onToggleSuspend,
  range,
  setRange,
  customStart,
  setCustomStart,
  customEnd,
  setCustomEnd,
}) {
  const [activeTab, setActiveTab] = useState("usage");
  const [confirmAction, setConfirmAction] = useState(null);
  const [actionReason, setActionReason] = useState("");

  const user = useMemo(
    () => adminApi.getUserById(userId, userStatusOverrides),
    [userId, userStatusOverrides],
  );

  if (!user) {
    return (
      <section className="admin-panel">
        <p>User record not found.</p>
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft aria-hidden="true" /> Back to User Management
        </Button>
      </section>
    );
  }

  const factor = getRangeFactor(range, customStart, customEnd);
  const scale = (val) => Math.max(0, Math.round(val * factor));
  const scaleFloat = (val) => Number((val * factor).toFixed(2));
  const isSuspended = user.status === "Suspended";
  const remainingBudget = Math.max(0, user.aiMonitoring.budgetLimitUsd - scaleFloat(user.aiMonitoring.spendUsd));
  const profileMatchesSearch = filterSearchRecords(
    [user],
    search,
    (record) => [
      record.name,
      record.email,
      record.id,
      record.startupName,
      record.startupPlan,
      record.status,
    ],
  ).length > 0;
  const profileSearch = profileMatchesSearch ? "" : search;
  const featureUsageRows = [
    { label: "AI requests", value: scale(user.featureUsage.aiRequests) },
    { label: "Prospects researched", value: scale(user.featureUsage.prospectsResearched) },
    { label: "Leads generated", value: scale(user.featureUsage.leadsGenerated) },
    { label: "Decision-maker searches", value: scale(user.featureUsage.decisionMakerSearches) },
    { label: "ICPs created", value: scale(user.featureUsage.icpsCreated) },
    { label: "Lead scoring actions", value: scale(user.featureUsage.leadScoringActions) },
    { label: "Emails drafted", value: scale(user.featureUsage.emailsDrafted) },
    { label: "Emails sent", value: scale(user.featureUsage.emailsSent) },
    { label: "Follow-ups", value: scale(user.featureUsage.followUps) },
    { label: "Meetings booked", value: scale(user.featureUsage.meetingsBooked) },
  ];
  const filteredFeatureUsageRows = filterSearchRecords(
    featureUsageRows,
    profileSearch,
    (row) => [row.label, row.value, numberFormat(row.value)],
  );
  const filteredAiFeatureRows = filterSearchRecords(
    user.aiMonitoring.byFeature,
    profileSearch,
    (row) => [row.feature, row.requests, row.tokens, row.cost, row.failed],
  );
  const filteredAiProviderRows = filterSearchRecords(
    user.aiMonitoring.byProvider,
    profileSearch,
    (row) => [row.provider, row.requests, row.tokens, row.units, row.cost, row.failed],
  );
  const filteredProspectHistory = filterSearchRecords(
    user.salesOutreach.prospectHistory,
    profileSearch,
    (item) => [item.date, item.target, item.stage, item.score],
  );
  const filteredFollowUps = filterSearchRecords(
    user.salesOutreach.followUps,
    profileSearch,
    (item) => [item.date, item.prospect, item.status],
  );
  const filteredPaymentHistory = filterSearchRecords(
    user.subscription?.paymentHistory || [],
    profileSearch,
    (item) => [item.txId, item.date, item.amount, item.method, item.status],
  );

  const loginHistoryInRange = user.loginHistory.filter((item) => {
    if (range !== "custom" || !customStart || !customEnd) return true;
    const itemDate = item.date.slice(0, 10);
    return itemDate >= customStart && itemDate <= customEnd;
  });
  const filteredLoginHistory = filterSearchRecords(
    loginHistoryInRange,
    profileSearch,
    (item) => [item.id, item.date, item.event, item.detail, item.status],
  );

  const handleConfirmStatusChange = () => {
    const nextStatus = confirmAction === "suspend" ? "Suspended" : "Active";
    onToggleSuspend(user, nextStatus, actionReason.trim());
    setConfirmAction(null);
    setActionReason("");
  };

  return (
    <>
      <div className="admin-profile-topbar">
        <Button variant="outline" size="sm" onClick={onBack}>
          <ArrowLeft aria-hidden="true" /> Back to User Management
        </Button>
        <div className="admin-profile-actions">
          <DateRangeControls
            range={range}
            setRange={setRange}
            customStart={customStart}
            setCustomStart={setCustomStart}
            customEnd={customEnd}
            setCustomEnd={setCustomEnd}
          />
          {isSuspended ? (
            <Button
              variant="default"
              size="sm"
              onClick={() => setConfirmAction("reactivate")}
            >
              <CheckCircle2 aria-hidden="true" /> Reactivate account
            </Button>
          ) : (
            <Button
              variant="destructive"
              size="sm"
              onClick={() => setConfirmAction("suspend")}
            >
              <ShieldAlert aria-hidden="true" /> Suspend account
            </Button>
          )}
        </div>
      </div>

      {confirmAction ? (
        <section className="admin-confirm-card" role="alertdialog" aria-label="Confirm founder action">
          <div>
            <strong>
              {confirmAction === "suspend"
                ? `Confirm suspension for ${user.name} (${user.email})?`
                : `Confirm reactivation for ${user.name} (${user.email})?`}
            </strong>
            <p>
              This Founder action will be recorded in Audit Logs. In this standalone preview, status changes are stored in session memory only until backend APIs are connected.
            </p>
            <input
              type="text"
              className="admin-confirm-input"
              placeholder="Optional audit note (e.g. Billing review, policy check)"
              value={actionReason}
              onChange={(e) => setActionReason(e.target.value)}
            />
          </div>
          <div className="admin-confirm-buttons">
            <Button variant="outline" size="sm" onClick={() => { setConfirmAction(null); setActionReason(""); }}>
              Cancel
            </Button>
            <Button
              variant={confirmAction === "suspend" ? "destructive" : "default"}
              size="sm"
              onClick={handleConfirmStatusChange}
            >
              {confirmAction === "suspend" ? "Confirm Suspend" : "Confirm Reactivate"}
            </Button>
          </div>
        </section>
      ) : null}

      <div className="admin-content-grid overview-grid">
        <section className="admin-panel">
          <div className="admin-panel-heading">
            <div>
              <h2>{user.name}</h2>
              <p>{user.email} · ID: <code>{user.id}</code></p>
            </div>
            <div className="admin-badge-pair">
              <span className="admin-scope-badge scope-individual">INDIVIDUAL USER</span>
              <StatusPill>{user.status}</StatusPill>
            </div>
          </div>
          <div className="admin-profile-kv">
            <div><span>Workspace role</span><strong>{user.workspaceRole}</strong></div>
            <div><span>Registration date</span><strong>{user.registrationDate}</strong></div>
            <div><span>Last login</span><strong>{user.lastLoginDisplay}</strong></div>
            <div><span>Account status</span><strong>{user.status}</strong></div>
          </div>
        </section>

        <section className="admin-panel">
          <div className="admin-panel-heading">
            <div>
              <h2>{user.startupName}</h2>
              <p>Startup ID: <code>{user.startupId}</code> · Shared workspace context</p>
            </div>
            <span className="admin-scope-badge scope-shared">STARTUP-LEVEL SHARED</span>
          </div>
          <div className="admin-profile-kv">
            <div><span>Subscription plan</span><strong>{user.startupPlan}</strong></div>
            <div><span>Startup status</span><strong>{user.startupStatus}</strong></div>
            <div><span>Workspace users</span><strong>{user.startupActiveUsers} active users</strong></div>
            <div><span>Data scope</span><strong>DEMO DATA</strong></div>
          </div>
        </section>
      </div>

      <div className="admin-profile-tabs" role="tablist" aria-label="User profile sections">
        <Button variant={activeTab === "usage" ? "default" : "outline"} size="sm" onClick={() => setActiveTab("usage")}>
          <Activity aria-hidden="true" /> Feature Usage
        </Button>
        <Button variant={activeTab === "ai" ? "default" : "outline"} size="sm" onClick={() => setActiveTab("ai")}>
          <Sparkles aria-hidden="true" /> AI & API Monitoring
        </Button>
        <Button variant={activeTab === "sales" ? "default" : "outline"} size="sm" onClick={() => setActiveTab("sales")}>
          <Target aria-hidden="true" /> Sales & Outreach
        </Button>
        <Button variant={activeTab === "billing" ? "default" : "outline"} size="sm" onClick={() => setActiveTab("billing")}>
          <CreditCard aria-hidden="true" /> Subscription & Payment
        </Button>
        <Button variant={activeTab === "logins" ? "default" : "outline"} size="sm" onClick={() => setActiveTab("logins")}>
          <KeyRound aria-hidden="true" /> Login & Account Activity
        </Button>
      </div>

      {activeTab === "usage" ? (
        <section className="admin-panel">
          <div className="admin-panel-heading">
            <div>
              <h2>Individual feature usage</h2>
              <p>Usage metrics attributed to {user.name} for the selected date range ({range === "custom" ? `${customStart || "start"} to ${customEnd || "end"}` : range}).</p>
            </div>
            <span className="admin-scope-badge scope-individual">INDIVIDUAL USER · DEMO DATA</span>
          </div>
          {filteredFeatureUsageRows.length ? (
            <div className="admin-feature-grid">
              {filteredFeatureUsageRows.map((row) => (
                <div className="admin-feature-stat" key={row.label}><span>{row.label}</span><strong>{numberFormat(row.value)}</strong></div>
              ))}
            </div>
          ) : <p className="admin-empty-cell">No results found.</p>}
        </section>
      ) : null}

      {activeTab === "ai" ? (
        <div className="admin-module-content">
          <div className="admin-metric-grid">
            <article className="admin-metric">
              <div className="admin-metric-icon"><Zap aria-hidden="true" /></div>
              <div className="admin-metric-copy">
                <p>Tokens consumed</p>
                <strong>{numberFormat(scale(user.aiMonitoring.tokensUsed))}</strong>
                <span>Individual usage · DEMO DATA</span>
              </div>
            </article>
            <article className="admin-metric">
              <div className="admin-metric-icon tone-amber"><Sparkles aria-hidden="true" /></div>
              <div className="admin-metric-copy">
                <p>Estimated AI cost</p>
                <strong>{currency.format(scaleFloat(user.aiMonitoring.spendUsd))}</strong>
                <span>Selected period</span>
              </div>
            </article>
            <article className="admin-metric">
              <div className="admin-metric-icon tone-teal"><ShieldCheck aria-hidden="true" /></div>
              <div className="admin-metric-copy">
                <p>Remaining budget</p>
                <strong>{currency.format(remainingBudget)}</strong>
                <span>Limit: {currency.format(user.aiMonitoring.budgetLimitUsd)}</span>
              </div>
            </article>
            <article className="admin-metric">
              <div className="admin-metric-icon tone-amber"><ShieldAlert aria-hidden="true" /></div>
              <div className="admin-metric-copy">
                <p>Failed requests</p>
                <strong>{numberFormat(scale(user.aiMonitoring.failedRequests))}</strong>
                <span>Provider errors / retries</span>
              </div>
            </article>
          </div>

          <div className="admin-content-grid">
            <section className="admin-panel">
              <div className="admin-panel-heading">
                <div><h2>AI usage by feature</h2><p>Breakdown of AI requests, tokens, and estimated cost by workflow.</p></div>
                <span className="admin-demo-badge">DEMO DATA</span>
              </div>
              <div className="admin-table-scroll">
                <table className="admin-data-table">
                  <thead>
                    <tr>
                      <th>Feature</th>
                      <th>Requests</th>
                      <th>Tokens</th>
                      <th>Est. cost</th>
                      <th>Failed</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredAiFeatureRows.map((row) => (
                      <tr key={row.feature}>
                        <td><strong>{row.feature}</strong></td>
                        <td>{numberFormat(scale(row.requests))}</td>
                        <td>{numberFormat(scale(row.tokens))}</td>
                        <td>{currency.format(scaleFloat(row.cost))}</td>
                        <td>{scale(row.failed)}</td>
                      </tr>
                    ))}
                    {!filteredAiFeatureRows.length ? <tr><td colSpan={5} className="admin-empty-cell">No results found.</td></tr> : null}
                  </tbody>
                </table>
              </div>
            </section>

            <section className="admin-panel">
              <div className="admin-panel-heading">
                <div><h2>API requests by provider</h2><p>Provider-level consumption and failure count.</p></div>
                <span className="admin-demo-badge">DEMO DATA</span>
              </div>
              <div className="admin-table-scroll">
                <table className="admin-data-table">
                  <thead>
                    <tr>
                      <th>Provider</th>
                      <th>Requests</th>
                      <th>Units / Tokens</th>
                      <th>Est. cost</th>
                      <th>Failed</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredAiProviderRows.map((row) => (
                      <tr key={row.provider}>
                        <td><strong>{row.provider}</strong></td>
                        <td>{numberFormat(scale(row.requests))}</td>
                        <td>{row.units || numberFormat(scale(row.tokens))}</td>
                        <td>{currency.format(scaleFloat(row.cost))}</td>
                        <td>{scale(row.failed)}</td>
                      </tr>
                    ))}
                    {!filteredAiProviderRows.length ? <tr><td colSpan={5} className="admin-empty-cell">No results found.</td></tr> : null}
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        </div>
      ) : null}

      {activeTab === "sales" ? (
        <div className="admin-module-content">
          <div className="admin-metric-grid">
            <article className="admin-metric">
              <div className="admin-metric-icon"><Search aria-hidden="true" /></div>
              <div className="admin-metric-copy">
                <p>Decision-makers researched</p>
                <strong>{numberFormat(scale(user.salesOutreach.decisionMakersFound))}</strong>
                <span>Individual research</span>
              </div>
            </article>
            <article className="admin-metric">
              <div className="admin-metric-icon tone-teal"><Network aria-hidden="true" /></div>
              <div className="admin-metric-copy">
                <p>Apollo outreach synced</p>
                <strong>{numberFormat(scale(user.salesOutreach.apolloOutreach.synced))}</strong>
                <span>{user.salesOutreach.apolloOutreach.sequencesActive} active sequences · {user.salesOutreach.apolloOutreach.errors} errors</span>
              </div>
            </article>
            <article className="admin-metric">
              <div className="admin-metric-icon tone-green"><Mail aria-hidden="true" /></div>
              <div className="admin-metric-copy">
                <p>Email delivery</p>
                <strong>{numberFormat(scale(user.salesOutreach.deliveryStats.delivered))}/{numberFormat(scale(user.salesOutreach.deliveryStats.sent))}</strong>
                <span>{scale(user.salesOutreach.deliveryStats.bounced)} bounced · {scale(user.salesOutreach.deliveryStats.replies)} replies</span>
              </div>
            </article>
            <article className="admin-metric">
              <div className="admin-metric-icon tone-amber"><CalendarDays aria-hidden="true" /></div>
              <div className="admin-metric-copy">
                <p>Meetings booked</p>
                <strong>{numberFormat(scale(user.salesOutreach.deliveryStats.meetings))}</strong>
                <span>Tracked from outreach</span>
              </div>
            </article>
          </div>

          <div className="admin-content-grid">
            <section className="admin-panel">
              <div className="admin-panel-heading">
                <div><h2>Prospect & lead scoring history</h2><p>Recent target accounts researched and scored.</p></div>
                <span className="admin-demo-badge">DEMO DATA</span>
              </div>
              <div className="admin-table-scroll">
                <table className="admin-data-table">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Target account</th>
                      <th>Stage</th>
                      <th>Lead score</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredProspectHistory.map((item) => (
                      <tr key={`${item.date}-${item.target}`}>
                        <td>{item.date}</td>
                        <td><strong>{item.target}</strong></td>
                        <td><StatusPill>{item.stage}</StatusPill></td>
                        <td><span className="admin-score-value">{item.score}/100</span></td>
                      </tr>
                    ))}
                    {!filteredProspectHistory.length ? <tr><td colSpan={4} className="admin-empty-cell">No results found.</td></tr> : null}
                  </tbody>
                </table>
              </div>
            </section>

            <section className="admin-panel">
              <div className="admin-panel-heading">
                <div><h2>Follow-up history</h2><p>Follow-up actions and reply status.</p></div>
                <span className="admin-demo-badge">DEMO DATA</span>
              </div>
              <div className="admin-table-scroll">
                <table className="admin-data-table">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Prospect</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredFollowUps.map((item) => (
                      <tr key={`${item.date}-${item.prospect}`}>
                        <td>{item.date}</td>
                        <td><strong>{item.prospect}</strong></td>
                        <td><StatusPill>{item.status}</StatusPill></td>
                      </tr>
                    ))}
                    {!filteredFollowUps.length ? (
                      <tr><td colSpan={3} className="admin-empty-cell">{profileSearch ? "No results found." : "No follow-ups recorded in sample."}</td></tr>
                    ) : null}
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        </div>
      ) : null}

      {activeTab === "billing" ? (
        <div className="admin-content-grid">
          <section className="admin-panel">
            <div className="admin-panel-heading">
              <div>
                <h2>Subscription & plan entitlements</h2>
                <p>Shared at the {user.startupName} workspace level.</p>
              </div>
              <span className="admin-scope-badge scope-shared">STARTUP-LEVEL SHARED · DEMO DATA</span>
            </div>
            {user.subscription ? (
              <div className="admin-profile-kv">
                <div><span>Current plan</span><strong>{user.subscription.plan}</strong></div>
                <div><span>Subscription status</span><strong>{user.subscription.status}</strong></div>
                <div><span>Start date</span><strong>{user.subscription.startDate}</strong></div>
                <div><span>Expiry / renewal date</span><strong>{user.subscription.expiryDate}</strong></div>
                <div><span>Monthly amount</span><strong>{currency.format(user.subscription.amount)}</strong></div>
                <div><span>Team seat limit</span><strong>{user.subscription.entitlements.seats} seats</strong></div>
                <div><span>Monthly AI request limit</span><strong>{numberFormat(user.subscription.entitlements.monthlyAiRequests)}</strong></div>
                <div><span>Monthly prospect limit</span><strong>{numberFormat(user.subscription.entitlements.monthlyProspects)}</strong></div>
              </div>
            ) : (
              <p>No subscription record attached.</p>
            )}
          </section>

          <section className="admin-panel">
            <div className="admin-panel-heading">
              <div><h2>Payment history</h2><p>Illustrative transaction records (not connected to live payment gateway).</p></div>
              <span className="admin-demo-badge">DEMO DATA</span>
            </div>
            <div className="admin-table-scroll">
              <table className="admin-data-table">
                <thead>
                  <tr>
                    <th>Transaction ID</th>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>Method</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredPaymentHistory.map((tx) => (
                    <tr key={tx.txId}>
                      <td><code>{tx.txId}</code></td>
                      <td>{tx.date}</td>
                      <td>{currency.format(tx.amount)}</td>
                      <td>{tx.method}</td>
                      <td><StatusPill>{tx.status}</StatusPill></td>
                    </tr>
                  ))}
                  {!filteredPaymentHistory.length ? (
                    <tr><td colSpan={5} className="admin-empty-cell">{profileSearch ? "No results found." : "No payment transactions recorded (Trial or no history)."}</td></tr>
                  ) : null}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      ) : null}

      {activeTab === "logins" ? (
        <section className="admin-panel">
          <div className="admin-panel-heading">
            <div>
              <h2>Login & account activity</h2>
              <p>Session history, last active time ({user.lastLoginDisplay}), and account events for {user.name}.</p>
            </div>
            <span className="admin-scope-badge scope-individual">INDIVIDUAL USER · DEMO DATA</span>
          </div>
          <div className="admin-table-scroll">
            <table className="admin-data-table">
              <thead>
                <tr>
                  <th>Timestamp</th>
                  <th>Event</th>
                  <th>Session / Detail</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {filteredLoginHistory.map((item) => (
                  <tr key={item.id}>
                    <td>{item.date}</td>
                    <td><strong>{item.event}</strong></td>
                    <td>{item.detail}</td>
                    <td><StatusPill>{item.status}</StatusPill></td>
                  </tr>
                ))}
                {!filteredLoginHistory.length ? (
                <tr><td colSpan={4} className="admin-empty-cell">{profileSearch ? "No results found." : "No login events in the selected custom date range."}</td></tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </section>
      ) : null}
    </>
  );
}
