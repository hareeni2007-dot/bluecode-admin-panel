import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  Bell,
  Building2,
  CalendarDays,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CircleDollarSign,
  Clock3,
  CreditCard,
  Download,
  FileBarChart2,
  Gauge,
  KeyRound,
  LayoutDashboard,
  LifeBuoy,
  LogOut,
  Mail,
  Menu,
  Network,
  Search,
  ShieldCheck,
  Sparkles,
  Target,
  Users,
  X,
  Zap,
} from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
const blueCodeLogo = { url: "/bluecode-logo.png" };
import { Button } from "@/components/ui/button";
import { adminApi, downloadCsv, FOUNDER_ROLE } from "./api-service.js";
import { calculateEngagementScore, getEngagementTier } from "./engagement.js";
import { filterSearchRecords, getModuleSearchQuery } from "./search.js";
import { StartupReportView } from "./StartupReportView.jsx";
import { DateRangeControls, UserProfileView, UsersPage } from "./UserManagement.jsx";

const modules = [
  { id: "dashboard", path: "/", label: "Dashboard", icon: LayoutDashboard },
  { id: "users", path: "/users", label: "User management", icon: Users },
  { id: "startups", path: "/startups", label: "Startup management", icon: Building2 },
  { id: "activity", path: "/activity", label: "User activity", icon: Activity },
  { id: "ai-usage", path: "/ai-usage", label: "AI usage", icon: Sparkles },
  { id: "prospects", path: "/prospects", label: "Prospect management", icon: Target },
  { id: "email", path: "/email", label: "Email activity", icon: Mail },
  { id: "subscriptions", path: "/subscriptions", label: "Subscriptions", icon: CreditCard },
  { id: "apis", path: "/apis", label: "API management", icon: Network },
  { id: "analytics", path: "/analytics", label: "Reports & analytics", icon: BarChart3 },
  { id: "support", path: "/support", label: "Support & audit logs", icon: LifeBuoy },
];

const ranges = [
  { value: "7d", label: "Last 7 days" },
  { value: "30d", label: "Last 30 days" },
  { value: "90d", label: "Last 90 days" },
  { value: "custom", label: "Custom range" },
];

const currency = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
});

const preciseCurrency = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

function numberFormat(value) {
  return new Intl.NumberFormat("en-US").format(value);
}

function titleCase(value) {
  return value.replaceAll("-", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function PageHeading({ eyebrow, title, description, action }) {
  return (
    <div className="admin-page-heading">
      <div>
        <p className="admin-eyebrow">{eyebrow}</p>
        <h1>{title}</h1>
        <p className="admin-page-description">{description}</p>
      </div>
      {action ? <div className="admin-heading-action">{action}</div> : null}
    </div>
  );
}

function MetricCard({ icon: Icon, label, value, detail, tone = "blue", trend }) {
  return (
    <article className="admin-metric">
      <div className={`admin-metric-icon tone-${tone}`}><Icon aria-hidden="true" /></div>
      <div className="admin-metric-copy">
        <p>{label}</p>
        <strong>{value}</strong>
        <span className={trend ? "admin-trend" : "admin-metric-detail"}>
          {trend ? <ArrowUpRight aria-hidden="true" /> : null}{detail}
        </span>
      </div>
    </article>
  );
}

function Panel({ title, subtitle, action, className = "", children }) {
  return (
    <section className={`admin-panel ${className}`}>
      <div className="admin-panel-heading">
        <div>
          <h2>{title}</h2>
          {subtitle ? <p>{subtitle}</p> : null}
        </div>
        {action ? <div className="admin-panel-action">{action}</div> : null}
      </div>
      {children}
    </section>
  );
}

function StatusPill({ children }) {
  const tone = String(children).toLowerCase().replaceAll(" ", "-").replaceAll("·", "");
  return <span className={`admin-status status-${tone}`}>{children}</span>;
}

function ChartTooltip({ active, payload, label, formatter }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="admin-chart-tooltip">
      <strong>{label}</strong>
      {payload.map((entry) => (
        <span key={entry.dataKey}>
          {entry.name}: {formatter ? formatter(entry.value) : numberFormat(entry.value)}
        </span>
      ))}
    </div>
  );
}

function TableTools({ rows, columns, filename, statusFilter, setStatusFilter, statuses }) {
  const visibleRows = rows.map((row) => Object.fromEntries(
    columns.map((column) => [
      column.label,
      column.exportValue ? column.exportValue(row) : row[column.key],
    ]),
  ));

  return (
    <div className="admin-table-tools">
      {statuses ? (
        <label className="admin-filter-label">
          <span>Status</span>
          <span className="admin-select-wrap">
            <select aria-label="Filter by status" value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)}>
              <option value="All statuses">All statuses</option>
              {statuses.map((status) => <option key={status} value={status}>{status}</option>)}
            </select>
            <ChevronDown aria-hidden="true" />
          </span>
        </label>
      ) : <span className="admin-table-count">{numberFormat(rows.length)} records</span>}
      <Button variant="outline" size="sm" onClick={() => downloadCsv(visibleRows, filename)} disabled={!visibleRows.length}>
        <Download aria-hidden="true" /> Export CSV
      </Button>
    </div>
  );
}

function DataTable({ rows, columns, search, sortBy, setSortBy, sortDirection, setSortDirection, page, setPage, statusFilter = "All statuses", statusKey = "status" }) {
  const pageSize = 5;
  const filteredRows = useMemo(() => {
    const filtered = filterSearchRecords(
      rows,
      search,
      (row) => columns.map((column) => (
        column.searchValue ? column.searchValue(row) : row[column.key]
      )),
      (row) => statusFilter === "All statuses" || row[statusKey] === statusFilter,
    );

    if (!sortBy) return filtered;
    return [...filtered].sort((first, second) => {
      const a = first[sortBy] ?? "";
      const b = second[sortBy] ?? "";
      const comparison = typeof a === "number" && typeof b === "number"
        ? a - b
        : String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: "base" });
      return sortDirection === "asc" ? comparison : -comparison;
    });
  }, [columns, rows, search, sortBy, sortDirection, statusFilter, statusKey]);

  const pageCount = Math.max(1, Math.ceil(filteredRows.length / pageSize));
  const currentPage = Math.min(page, pageCount);
  const paginatedRows = filteredRows.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const updateSort = (key) => {
    if (sortBy === key) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortBy(key);
      setSortDirection("asc");
    }
    setPage(1);
  };

  return (
    <div className="admin-table-frame">
      <div className="admin-table-scroll">
        <table className="admin-data-table">
          <thead>
            <tr>
              {columns.map((column) => (
                <th key={column.key} scope="col">
                  <Button variant="ghost" size="sm" className="admin-sort-button" onClick={() => updateSort(column.sortKey || column.key)}>
                    {column.label}
                    {sortBy === (column.sortKey || column.key) ? (
                      sortDirection === "asc" ? <ChevronDown aria-label="Sorted ascending" /> : <ArrowDownRight aria-label="Sorted descending" />
                    ) : null}
                  </Button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {paginatedRows.map((row) => (
              <tr key={row.id}>
                {columns.map((column) => (
                  <td key={column.key}>
                    {column.render ? column.render(row) : row[column.key]}
                  </td>
                ))}
              </tr>
            ))}
            {!paginatedRows.length ? (
              <tr><td className="admin-empty-cell" colSpan={columns.length}>No results found.</td></tr>
            ) : null}
          </tbody>
        </table>
      </div>
      <div className="admin-pagination">
        <span>{filteredRows.length ? `${(currentPage - 1) * pageSize + 1}–${Math.min(currentPage * pageSize, filteredRows.length)} of ${filteredRows.length}` : "0 results"}</span>
        <div>
          <Button variant="outline" size="icon" aria-label="Previous page" onClick={() => setPage(Math.max(1, currentPage - 1))} disabled={currentPage === 1}>
            <ChevronLeft aria-hidden="true" />
          </Button>
          <span>Page {currentPage} of {pageCount}</span>
          <Button variant="outline" size="icon" aria-label="Next page" onClick={() => setPage(Math.min(pageCount, currentPage + 1))} disabled={currentPage >= pageCount}>
            <ChevronRight aria-hidden="true" />
          </Button>
        </div>
      </div>
    </div>
  );
}

function TrendChart({ data, metric = "aiSpend", formatter }) {
  return (
    <div className="admin-chart" aria-label="Usage trend chart">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 12, right: 8, left: -18, bottom: 0 }}>
          <CartesianGrid vertical={false} stroke="var(--chart-grid)" strokeDasharray="4 5" />
          <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{ fill: "var(--chart-label)", fontSize: 12 }} />
          <YAxis axisLine={false} tickLine={false} tick={{ fill: "var(--chart-label)", fontSize: 12 }} tickFormatter={formatter || numberFormat} />
          <Tooltip content={<ChartTooltip formatter={formatter} />} />
          <Area type="monotone" dataKey={metric} name={metric === "aiSpend" ? "AI spend" : titleCase(metric)} stroke="var(--chart-1)" strokeWidth={2.5} fill="var(--chart-area)" activeDot={{ r: 4, fill: "var(--chart-1)" }} isAnimationActive={false} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

function FeatureChart({ data }) {
  return (
    <div className="admin-chart" aria-label="Feature usage chart">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ top: 0, right: 10, left: 20, bottom: 0 }}>
          <CartesianGrid horizontal={false} stroke="var(--chart-grid)" />
          <XAxis type="number" axisLine={false} tickLine={false} tick={{ fill: "var(--chart-label)", fontSize: 12 }} />
          <YAxis dataKey="feature" type="category" width={155} axisLine={false} tickLine={false} tick={{ fill: "var(--chart-label)", fontSize: 12 }} />
          <Tooltip content={<ChartTooltip />} />
          <Bar dataKey="usage" name="Actions" fill="var(--chart-2)" radius={[0, 4, 4, 0]} barSize={14} isAnimationActive={false} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

function Dashboard({ onNavigate, range, setRange, customStart, setCustomStart, customEnd, setCustomEnd, search }) {
  const summary = adminApi.getDashboardSummary();
  const trend = adminApi.getUsageTrend(range);
  const recentActivity = filterSearchRecords(
    adminApi.listUserActivity(),
    search,
    (item) => [item.id, item.founder, item.startup, item.sessions, item.activeDays, item.featuresUsed, item.lastSeen, item.mostUsedFeature],
  ).slice(0, 4);

  return (
    <>
      <PageHeading
        eyebrow="PLATFORM OVERVIEW"
        title="Good evening, Admin."
        description="A clear view of founder engagement, platform usage and operating costs."
        action={<Button onClick={() => downloadCsv([summary], "bluecode-platform-summary.csv")}><Download aria-hidden="true" /> Export summary</Button>}
      />
      <div className="admin-metric-grid">
        <MetricCard icon={Building2} label="Registered startups" value={numberFormat(summary.registeredStartups)} detail={`${numberFormat(summary.activeStartups)} active this period`} trend />
        <MetricCard icon={Sparkles} label="AI spend" value={preciseCurrency.format(summary.aiSpend)} detail={`${numberFormat(summary.aiRequests)} AI requests`} tone="teal" />
        <MetricCard icon={Target} label="Prospects researched" value={numberFormat(summary.prospectsResearched)} detail="Across all customer workspaces" tone="green" />
        <MetricCard icon={Mail} label="Email drafts generated" value={numberFormat(summary.emailDraftsGenerated)} detail="Aggregate activity only" tone="amber" />
      </div>
      <div className="admin-content-grid overview-grid">
        <Panel
          title="AI operating cost"
          subtitle="Illustrative USD spend over the selected period"
          action={<RangeSelect range={range} setRange={setRange} customStart={customStart} setCustomStart={setCustomStart} customEnd={customEnd} setCustomEnd={setCustomEnd} />}
          className="admin-chart-panel"
        >
          <div className="admin-chart-summary"><strong>{preciseCurrency.format(summary.aiSpend)}</strong><span><ArrowUpRight aria-hidden="true" /> 8.4% vs prior period</span></div>
          <TrendChart data={trend} formatter={(value) => `$${numberFormat(value)}`} />
        </Panel>
        <Panel title="Feature activity" subtitle="Most-used founder workflow actions">
          <FeatureChart data={adminApi.listFeatureUsage()} />
          <p className="admin-footnote">Usage counts are aggregate and illustrative. No prospect records or message content are shown.</p>
        </Panel>
      </div>
      <div className="admin-content-grid overview-lower-grid">
        <Panel title="Founder activity" subtitle="Recent workspace engagement at a glance" action={<Button variant="ghost" size="sm" onClick={() => onNavigate("/activity")}>View activity <ArrowRight aria-hidden="true" /></Button>}>
          <div className="admin-activity-list">
            {recentActivity.length ? recentActivity.map((item) => (
              <div className="admin-activity-row" key={item.id}>
                <span className="admin-activity-icon"><Activity aria-hidden="true" /></span>
                <div><strong>{item.founder} <span>· {item.startup}</span></strong><p>{item.sessions} sessions · {item.featuresUsed} features used · {item.mostUsedFeature}</p></div>
                <span className="admin-activity-time">{item.lastSeen}</span>
              </div>
            )) : <p className="admin-empty-cell">No results found.</p>}
          </div>
        </Panel>
        <Panel title="Subscription snapshot" subtitle="Current illustrative account mix" action={<Button variant="ghost" size="sm" onClick={() => onNavigate("/subscriptions")}>Subscriptions <ArrowRight aria-hidden="true" /></Button>}>
          <div className="admin-subscription-snapshot">
            <div><span>Monthly recurring revenue</span><strong>{currency.format(summary.monthlyRecurringRevenue)}</strong></div>
            <div><span>Active subscriptions</span><strong>31</strong></div>
            <div><span>Trials in progress</span><strong>8</strong></div>
            <div><span>Hunter credits used</span><strong>{numberFormat(summary.hunterCredits)}</strong></div>
          </div>
          <p className="admin-footnote">Figures are sample values for this admin preview, not live account or billing data.</p>
        </Panel>
      </div>
    </>
  );
}

function RangeSelect({ range, setRange, customStart, setCustomStart, customEnd, setCustomEnd }) {
  return (
    <DateRangeControls
      range={range}
      setRange={setRange}
      customStart={customStart}
      setCustomStart={setCustomStart}
      customEnd={customEnd}
      setCustomEnd={setCustomEnd}
    />
  );
}

function StartupsPage({ common, onSelectStartup, onAuditAction }) {
  const rows = adminApi.listStartupsWithEngagement();
  const inactiveCount = rows.filter((row) => row.inactivity.inactive).length;
  const upgradeCount = rows.filter((row) => row.upgrade.eligible).length;
  const columns = [
    {
      key: "name",
      label: "Startup",
      searchValue: (row) => `${row.id} ${row.name} ${row.founder} ${row.inactivity.inactive ? "inactive" : ""} ${row.upgrade.eligible ? `upgrade ${row.upgrade.recommendedPlan}` : ""}`,
      render: (row) => (
        <div className="admin-company-cell">
          <span className="admin-company-mark">{row.name.slice(0, 1)}</span>
          <span>
            <strong>{row.name}</strong>
            <small>Founder {row.founder} · {row.id}</small>
          </span>
        </div>
      ),
    },
    { key: "plan", label: "Plan", render: (row) => <span className="admin-plan-label">{row.plan}</span> },
    {
      key: "status",
      label: "Status",
      searchValue: (row) => `${row.status} ${row.inactivity.inactive ? "inactive" : "active"}`,
      render: (row) => (
        <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
          <StatusPill>{row.status}</StatusPill>
          {row.inactivity.inactive ? <StatusPill>At risk</StatusPill> : null}
        </div>
      ),
    },
    {
      key: "score",
      label: "Engagement",
      searchValue: (row) => `${row.score}/100 ${row.tier}`,
      render: (row) => (
        <div className="admin-score-cell">
          <strong>{row.score}/100</strong>
          <StatusPill>{row.tier}</StatusPill>
        </div>
      ),
    },
    {
      key: "upgrade",
      label: "Signals",
      searchValue: (row) => (row.upgrade.eligible ? `Upgrade to ${row.upgrade.recommendedPlan}` : row.inactivity.inactive ? "Inactive" : "Aligned"),
      render: (row) =>
        row.upgrade.eligible ? (
          <StatusPill>{`Upgrade · ${row.upgrade.recommendedPlan}`}</StatusPill>
        ) : row.inactivity.inactive ? (
          <StatusPill>At risk</StatusPill>
        ) : (
          <span className="admin-table-count">Aligned</span>
        ),
    },
    { key: "aiSpend", label: "AI spend", render: (row) => preciseCurrency.format(row.aiSpend) },
    { key: "hunterCredits", label: "Hunter credits", render: (row) => numberFormat(row.hunterCredits) },
    { key: "lastActive", label: "Last active" },
    {
      key: "actions",
      label: "Report",
      searchValue: () => "",
      render: (row) => (
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            if (typeof onAuditAction === "function") {
              onAuditAction(`Viewed startup activity report for ${row.name} (${row.id})`, "Startup Management", "Info");
            }
            onSelectStartup(row.id);
          }}
        >
          View report
        </Button>
      ),
    },
  ];

  const handleExportStartups = () => {
    downloadCsv(
      rows.map((row) => ({
        Startup: row.name,
        Founder: row.founder,
        Plan: row.plan,
        Status: row.status,
        "Engagement score": `${row.score}/100`,
        "Engagement level": row.tier,
        "Inactive flag": row.inactivity.inactive ? "Inactive" : "Active",
        "Upgrade opportunity": row.upgrade.eligible ? row.upgrade.recommendedPlan : "None",
        "AI spend (USD)": row.aiSpend,
        "Hunter credits": row.hunterCredits,
        "Last active": row.lastActive,
      })),
      "bluecode-startups.csv",
    );
    if (typeof onAuditAction === "function") {
      onAuditAction("Exported startup engagement directory CSV", "Startup Management", "Info");
    }
  };

  return (
    <>
      <PageHeading eyebrow="CUSTOMER ACCOUNTS" title="Startup management" description="Review subscriptions, computed engagement scores (/100), inactivity flags, and upgrade opportunities." action={<Button variant="outline" onClick={handleExportStartups}><Download aria-hidden="true" /> Export startups</Button>} />
      <div className="admin-metric-grid">
        <MetricCard icon={Building2} label="Accounts in sample" value={rows.length} detail="Representative workspaces" />
        <MetricCard icon={Gauge} label="Engaged founders" value={rows.filter((row) => row.tier === "Engaged").length} detail="Score of 70/100 or higher" tone="green" />
        <MetricCard icon={Clock3} label="Inactive / at-risk" value={inactiveCount} detail="14+ days inactive or flagged at risk" tone="amber" />
        <MetricCard icon={ArrowUpRight} label="Upgrade opportunities" value={upgradeCount} detail="High-engagement Trial / Starter / Growth" tone="teal" />
      </div>
      <Panel title="Customer directory" subtitle="Scores are computed from available sample activity data (not live customer scores). Click View report for full breakdown.">
        <TableTools rows={rows} columns={columns} filename="bluecode-startups.csv" statusFilter={common.statusFilter} setStatusFilter={common.setStatusFilter} statuses={["Active", "Trial", "At risk"]} />
        <DataTable {...common} rows={rows} columns={columns} />
      </Panel>
      <p className="admin-scoring-note"><ShieldCheck aria-hidden="true" /> Weighted 100-point engagement rubric calculated from illustrative workspace activity data, not real customer data.</p>
    </>
  );
}

function ActivityPage({ common, onSelectStartup, onAuditAction }) {
  const rows = adminApi.listUserActivity();
  const startupsList = adminApi.listStartups();
  const columns = [
    { key: "founder", label: "Founder" },
    { key: "startup", label: "Startup" },
    { key: "sessions", label: "Sessions" },
    { key: "activeDays", label: "Active days" },
    { key: "featuresUsed", label: "Features used" },
    { key: "mostUsedFeature", label: "Most-used feature" },
    { key: "lastSeen", label: "Last active" },
    {
      key: "report",
      label: "Activity report",
      searchValue: () => "",
      render: (row) => {
        const match = startupsList.find((s) => s.name === row.startup);
        return match ? (
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              if (typeof onAuditAction === "function") {
                onAuditAction(`Opened activity report for ${row.startup} (${match.id})`, "User Activity", "Info");
              }
              onSelectStartup(match.id);
            }}
          >
            View report
          </Button>
        ) : null;
      },
    },
  ];
  const totalSessions = rows.reduce((total, row) => total + row.sessions, 0);

  return (
    <>
      <PageHeading eyebrow="FOUNDER ACTIVITY" title="User activity tracking" description="Understand return frequency, session patterns and feature adoption without collecting keystrokes or screen recordings." />
      <div className="admin-metric-grid admin-metric-grid-compact">
        <MetricCard icon={Users} label="Founders in sample" value={rows.length} detail="Across 8 workspaces" />
        <MetricCard icon={Activity} label="Sessions this period" value={numberFormat(totalSessions)} detail="Aggregate session counts" tone="teal" />
        <MetricCard icon={Target} label="Average features used" value="5.8" detail="Per founder workspace" tone="green" />
      </div>
      <Panel title="Founder-wise activity" subtitle="Activity counts are aggregated by startup and founder; no individual prospect data is exposed.">
        <TableTools rows={rows} columns={columns} filename="bluecode-user-activity.csv" />
        <DataTable {...common} rows={rows} columns={columns} />
      </Panel>
    </>
  );
}

function AiUsagePage({ common, range, setRange, customStart, setCustomStart, customEnd, setCustomEnd }) {
  const rows = adminApi.listAiUsage();
  const totalRequests = rows.reduce((total, row) => total + row.requests, 0);
  const totalTokens = rows.reduce((total, row) => total + row.tokens, 0);
  const totalCost = rows.reduce((total, row) => total + row.cost, 0);
  const totalFailed = rows.reduce((total, row) => total + (row.failedRequests || 0), 0);
  const columns = [
    { key: "startup", label: "Startup" },
    { key: "provider", label: "AI provider" },
    { key: "requests", label: "Requests", render: (row) => numberFormat(row.requests) },
    { key: "failedRequests", label: "Failed", render: (row) => numberFormat(row.failedRequests || 0) },
    { key: "tokens", label: "Tokens", render: (row) => `${(row.tokens / 1000).toFixed(1)}K` },
    { key: "cost", label: "Estimated cost", render: (row) => preciseCurrency.format(row.cost) },
    { key: "budgetLimit", label: "Remaining budget", render: (row) => preciseCurrency.format(Math.max(0, (row.budgetLimit || 0) - row.cost)) },
  ];

  return (
    <>
      <PageHeading eyebrow="AI OPERATIONS" title="AI usage monitoring" description="Track customer-wise requests, tokens, failed requests, budget limits, and estimated provider costs." action={<Button variant="outline" onClick={() => downloadCsv(rows.map((row) => ({ Startup: row.startup, Provider: row.provider, Requests: row.requests, Failed: row.failedRequests || 0, Tokens: row.tokens, "Estimated cost (USD)": row.cost, "Remaining budget (USD)": Math.max(0, (row.budgetLimit || 0) - row.cost), Period: row.period })), "bluecode-ai-usage.csv")}><Download aria-hidden="true" /> Export usage</Button>} />
      <div className="admin-metric-grid">
        <MetricCard icon={Zap} label="AI requests" value={numberFormat(totalRequests)} detail="Across sample workspaces" />
        <MetricCard icon={Sparkles} label="Tokens consumed" value={`${(totalTokens / 1000000).toFixed(2)}M`} detail="Aggregate provider usage" tone="teal" />
        <MetricCard icon={CircleDollarSign} label="Estimated AI cost" value={preciseCurrency.format(totalCost)} detail="USD · sample only" tone="amber" />
        <MetricCard icon={Activity} label="Failed requests" value={numberFormat(totalFailed)} detail="Errors / rate-limit retries" tone="amber" />
      </div>
      <Panel title="AI cost trend" subtitle="Estimated provider cost by selected time range" action={<RangeSelect range={range} setRange={setRange} customStart={customStart} setCustomStart={setCustomStart} customEnd={customEnd} setCustomEnd={setCustomEnd} />} className="admin-chart-panel admin-single-chart">
        <TrendChart data={adminApi.getUsageTrend(range)} formatter={(value) => `$${numberFormat(value)}`} />
      </Panel>
      <Panel title="Customer-wise AI consumption" subtitle="Usage is shown in aggregate. No prompt or generated content is included.">
        <TableTools rows={rows} columns={columns} filename="bluecode-ai-usage.csv" />
        <DataTable {...common} rows={rows} columns={columns} />
      </Panel>
    </>
  );
}

function ProspectsPage({ common }) {
  const rows = adminApi.listProspectActivity();
  const total = rows.reduce((sum, row) => sum + row.researched, 0);
  const qualified = rows.reduce((sum, row) => sum + row.qualified, 0);
  const decisionMakers = rows.reduce((sum, row) => sum + row.decisionMakers, 0);
  const columns = [
    { key: "startup", label: "Startup" },
    { key: "researched", label: "Researched", render: (row) => numberFormat(row.researched) },
    { key: "qualified", label: "Qualified", render: (row) => numberFormat(row.qualified) },
    { key: "decisionMakers", label: "Decision-makers", render: (row) => numberFormat(row.decisionMakers) },
    { key: "buyingSignals", label: "Signals analyzed", render: (row) => numberFormat(row.buyingSignals) },
    { key: "engagementScore", label: "Engagement", render: (row) => <span className="admin-score-value">{row.engagementScore}/100</span> },
  ];

  return (
    <>
      <PageHeading eyebrow="SALES WORKFLOWS" title="Prospect management" description="Monitor research volume, qualification and buying-signal analysis by startup." />
      <div className="admin-metric-grid admin-metric-grid-compact">
        <MetricCard icon={Search} label="Prospects researched" value={numberFormat(total)} detail="Aggregate sample activity" />
        <MetricCard icon={Check} label="Prospects qualified" value={numberFormat(qualified)} detail="Qualification actions" tone="green" />
        <MetricCard icon={Users} label="Decision-makers found" value={numberFormat(decisionMakers)} detail="No contact details shown" tone="teal" />
      </div>
      <Panel title="Startup-wise prospect activity" subtitle="Only aggregate workflow counts are shown; prospect identities and contact details are excluded.">
        <TableTools rows={rows} columns={columns} filename="bluecode-prospect-activity.csv" />
        <DataTable {...common} rows={rows} columns={columns} />
      </Panel>
    </>
  );
}

function EmailActivityPage({ common }) {
  const rows = adminApi.listEmailActivity();
  const sum = (key) => rows.reduce((total, row) => total + row[key], 0);
  const columns = [
    { key: "startup", label: "Startup" },
    { key: "drafts", label: "Drafts generated", render: (row) => numberFormat(row.drafts) },
    { key: "approved", label: "Approved", render: (row) => numberFormat(row.approved) },
    { key: "sent", label: "Sent", render: (row) => numberFormat(row.sent) },
    { key: "bounced", label: "Bounced", render: (row) => numberFormat(row.bounced) },
    { key: "replies", label: "Replies", render: (row) => numberFormat(row.replies) },
  ];

  return (
    <>
      <PageHeading eyebrow="OUTREACH OPERATIONS" title="Email activity" description="See aggregate draft, approval, delivery and reply counts without exposing message text or recipients." />
      <div className="admin-metric-grid admin-metric-grid-compact">
        <MetricCard icon={Mail} label="Drafts generated" value={numberFormat(sum("drafts"))} detail="All customer workspaces" />
        <MetricCard icon={Check} label="Approved" value={numberFormat(sum("approved"))} detail="Founder-approved drafts" tone="green" />
        <MetricCard icon={ArrowUpRight} label="Emails sent" value={numberFormat(sum("sent"))} detail="Aggregate count only" tone="teal" />
        <MetricCard icon={Activity} label="Replies recorded" value={numberFormat(sum("replies"))} detail="Email contents excluded" tone="amber" />
      </div>
      <Panel title="Startup-wise email activity" subtitle="Counts only. Email subject, body, recipient and provider payloads are not displayed.">
        <TableTools rows={rows} columns={columns} filename="bluecode-email-activity.csv" />
        <DataTable {...common} rows={rows} columns={columns} />
      </Panel>
    </>
  );
}

function SubscriptionsPage({ common }) {
  const rows = adminApi.listSubscriptions();
  const active = rows.filter((row) => row.status === "Active").length;
  const trials = rows.filter((row) => row.status === "Trial").length;
  const revenue = rows.filter((row) => row.status === "Active").reduce((total, row) => total + row.amount, 0);
  const columns = [
    { key: "startup", label: "Startup" },
    { key: "plan", label: "Plan" },
    { key: "status", label: "Status", render: (row) => <StatusPill>{row.status}</StatusPill> },
    { key: "amount", label: "Monthly amount", render: (row) => preciseCurrency.format(row.amount) },
    { key: "payment", label: "Payment status", render: (row) => <StatusPill>{row.payment}</StatusPill> },
    { key: "nextDate", label: "Next billing date" },
  ];

  return (
    <>
      <PageHeading eyebrow="CUSTOMER BILLING" title="Subscription management" description="Review plan mix, trial status and illustrative recurring revenue." action={<Button variant="outline" onClick={() => downloadCsv(rows.map((row) => ({ Startup: row.startup, Plan: row.plan, Status: row.status, "Monthly amount (USD)": row.amount, "Payment status": row.payment, "Next billing date": row.nextDate })), "bluecode-subscriptions.csv")}><Download aria-hidden="true" /> Export subscriptions</Button>} />
      <div className="admin-metric-grid admin-metric-grid-compact">
        <MetricCard icon={CreditCard} label="Active subscriptions" value={active} detail="Sample accounts" />
        <MetricCard icon={Clock3} label="Trials in progress" value={trials} detail="Illustrative trial states" tone="teal" />
        <MetricCard icon={CircleDollarSign} label="Sample MRR" value={currency.format(revenue)} detail="USD · not connected to billing" tone="green" />
      </div>
      <Panel title="Plan and payment status" subtitle="No payment actions are available in this front-end preview.">
        <TableTools rows={rows} columns={columns} filename="bluecode-subscriptions.csv" statusFilter={common.statusFilter} setStatusFilter={common.setStatusFilter} statuses={["Active", "Trial", "Past due"]} />
        <DataTable {...common} rows={rows} columns={columns} />
      </Panel>
    </>
  );
}

function ApisPage({ common }) {
  const rows = adminApi.listApiUsage();
  const [monitored, setMonitored] = useState(() => new Set(rows.map((row) => row.id)));
  const totalSpend = rows.reduce((total, row) => total + row.spend, 0);
  const columns = [
    { key: "provider", label: "Provider" },
    { key: "category", label: "Service" },
    { key: "requests", label: "Requests", render: (row) => numberFormat(row.requests) },
    { key: "failedRequests", label: "Failed", render: (row) => numberFormat(row.failedRequests || 0) },
    { key: "units", label: "Usage units" },
    { key: "spend", label: "Estimated cost", render: (row) => preciseCurrency.format(row.spend) },
    { key: "budgetLimit", label: "Remaining budget", render: (row) => preciseCurrency.format(Math.max(0, (row.budgetLimit || 0) - row.spend)) },
    { key: "status", label: "Demo connection", render: (row) => <StatusPill>{row.status}</StatusPill> },
  ];

  return (
    <>
      <PageHeading eyebrow="INTEGRATION COSTS" title="API management" description="Monitor approved provider usage and estimated spend. No credentials are stored or exposed here." />
      <div className="admin-metric-grid admin-metric-grid-compact">
        <MetricCard icon={KeyRound} label="Providers monitored" value={rows.length} detail="Anthropic, OpenAI and Hunter" />
        <MetricCard icon={CircleDollarSign} label="Estimated API spend" value={preciseCurrency.format(totalSpend)} detail="Illustrative USD only" tone="amber" />
        <MetricCard icon={Zap} label="Hunter credits" value={numberFormat(adminApi.getDashboardSummary().hunterCredits)} detail="Aggregate credit use" tone="teal" />
      </div>
      <Panel title="Provider consumption" subtitle="Only the documented Anthropic, OpenAI and Hunter services are included.">
        <TableTools rows={rows} columns={columns} filename="bluecode-api-usage.csv" />
        <DataTable {...common} rows={rows} columns={columns} />
      </Panel>
      <Panel title="Monitoring controls" subtitle="Local preview controls only; they do not connect to or pause any live provider." className="admin-provider-panel">
        <div className="admin-provider-list">
          {rows.map((provider) => {
            const isMonitored = monitored.has(provider.id);
            return (
              <div className="admin-provider-row" key={provider.id}>
                <span className="admin-provider-icon"><Network aria-hidden="true" /></span>
                <div><strong>{provider.provider}</strong><small>{provider.category} · {numberFormat(provider.requests)} requests in sample</small></div>
                <StatusPill>{isMonitored ? "Monitoring on" : "Monitoring paused"}</StatusPill>
                <Button variant={isMonitored ? "outline" : "secondary"} size="sm" onClick={() => setMonitored((current) => {
                  const next = new Set(current);
                  if (next.has(provider.id)) next.delete(provider.id);
                  else next.add(provider.id);
                  return next;
                })}>
                  {isMonitored ? "Pause preview" : "Resume preview"}
                </Button>
              </div>
            );
          })}
        </div>
      </Panel>
    </>
  );
}

function AnalyticsPage({ common, range, setRange, customStart, setCustomStart, customEnd, setCustomEnd }) {
  const rows = adminApi.listStartups().map((startup) => ({
    id: startup.id,
    startup: startup.name,
    founder: startup.founder,
    prospects: startup.prospectsResearched,
    drafts: startup.emailDrafts,
    aiSpend: startup.aiSpend,
    hunterCredits: startup.hunterCredits,
    score: calculateEngagementScore(startup.engagement),
  }));
  const columns = [
    { key: "startup", label: "Startup", searchValue: (row) => `${row.startup} ${row.founder}` },
    { key: "prospects", label: "Prospects researched", render: (row) => numberFormat(row.prospects) },
    { key: "drafts", label: "Email drafts", render: (row) => numberFormat(row.drafts) },
    { key: "aiSpend", label: "AI spend", render: (row) => preciseCurrency.format(row.aiSpend) },
    { key: "hunterCredits", label: "Hunter credits", render: (row) => numberFormat(row.hunterCredits) },
    { key: "score", label: "Engagement score", render: (row) => `${row.score}/100` },
  ];

  return (
    <>
      <PageHeading eyebrow="PLATFORM INTELLIGENCE" title="Reports & analytics" description="Compare startup-wise performance, feature usage and operating costs." action={<RangeSelect range={range} setRange={setRange} customStart={customStart} setCustomStart={setCustomStart} customEnd={customEnd} setCustomEnd={setCustomEnd} />} />
      <div className="admin-content-grid overview-grid">
        <Panel title="Prospect research trend" subtitle="Aggregate research activity in the selected time range" className="admin-chart-panel">
          <TrendChart data={adminApi.getUsageTrend(range)} metric="prospects" />
        </Panel>
        <Panel title="Feature-wise usage" subtitle="Aggregate workflow activity">
          <FeatureChart data={adminApi.listFeatureUsage()} />
        </Panel>
      </div>
      <Panel title="Startup-wise analytics" subtitle="Compare usage and engagement without accessing customer prospect details.">
        <TableTools rows={rows} columns={columns} filename="bluecode-startup-analytics.csv" />
        <DataTable {...common} rows={rows} columns={columns} />
      </Panel>
      <p className="admin-footnote admin-standalone-note"><FileBarChart2 aria-hidden="true" /> All report figures are mock values. Currency is USD and can be changed for INR during backend integration.</p>
    </>
  );
}

function SupportPage({ common, auditEvents, retentionDays, onUpdateRetention, onPurgeExpiredLogs, onAuditAction }) {
  const rows = auditEvents;
  const filteredSupportCategories = filterSearchRecords(
    [
      { label: "Account & access", count: 4, note: "Login and role questions" },
      { label: "Usage & quotas", count: 3, note: "Usage-limit clarification" },
      { label: "Billing & plans", count: 2, note: "Subscription assistance" },
    ],
    common.search,
    (item) => [item.label, item.count, item.note],
  );
  const columns = [
    { key: "time", label: "Time" },
    { key: "actor", label: "Actor" },
    { key: "event", label: "Event" },
    { key: "area", label: "Area" },
    { key: "level", label: "Type", render: (row) => <StatusPill>{row.level}</StatusPill> },
  ];
  const handleExportAudit = () => {
    downloadCsv(rows, "bluecode-audit-log.csv");
    if (typeof onAuditAction === "function") {
      onAuditAction("Exported admin audit log CSV", "Operations & Governance", "Info");
    }
  };
  return (
    <>
      <PageHeading eyebrow="OPERATIONS & GOVERNANCE" title="Support & audit logs" description="Review operational issue categories, security guardrails, data retention controls, and administrative audit events." action={<Button variant="outline" onClick={handleExportAudit}><Download aria-hidden="true" /> Export audit log</Button>} />
      <div className="admin-content-grid support-grid">
        <Panel title="Support queue overview" subtitle="Category totals only; no ticket messages or customer identifiers.">
          <div className="admin-support-categories">
            {filteredSupportCategories.length ? filteredSupportCategories.map((item) => <div className="admin-support-row" key={item.label}><span className="admin-support-icon"><LifeBuoy aria-hidden="true" /></span><span><strong>{item.label}</strong><small>{item.note}</small></span><b>{item.count}</b></div>) : <p className="admin-empty-cell">No results found.</p>}
          </div>
        </Panel>
        <Panel title="Access & security guardrails" subtitle="Founder-only RBAC, tenant isolation, and privacy safeguards.">
          <div className="admin-guardrail-list">
            <p><ShieldCheck aria-hidden="true" /><span><strong>Separate Admin & customer authentication</strong><small>Admin-only access; public admin registration disabled (backend JWT/cookie check pending)</small></span></p>
            <p><KeyRound aria-hidden="true" /><span><strong>Multi-tenant isolation & encrypted storage</strong><small>Queries scoped by startup ID; TLS 1.3 & AES-256 KMS enforcement pending backend</small></span></p>
            <p><Users aria-hidden="true" /><span><strong>Restricted customer data & no personal monitoring</strong><small>Prospect lists, email content, keystrokes, and screen recordings are never collected or exposed</small></span></p>
          </div>
        </Panel>
      </div>
      <Panel
        title="Data retention & deletion controls"
        subtitle="Configure audit/activity retention window and trigger sample log cleanup (persisted backend cron & KMS deletion pending)."
        action={
          <div style={{ display: "flex", gap: "8px", alignItems: "center", flexWrap: "wrap" }}>
            <label className="admin-filter-label">
              <span>Retention</span>
              <span className="admin-select-wrap">
                <select
                  aria-label="Data retention window"
                  value={retentionDays}
                  onChange={(e) => onUpdateRetention(Number(e.target.value))}
                >
                  <option value={90}>90 days</option>
                  <option value={180}>180 days</option>
                  <option value={365}>365 days</option>
                </select>
                <ChevronDown aria-hidden="true" />
              </span>
            </label>
            <Button variant="outline" size="sm" onClick={onPurgeExpiredLogs}>
              Purge expired demo logs
            </Button>
          </div>
        }
      >
        <p className="admin-footnote" style={{ margin: 0 }}>
          Current policy: retain administrative audit logs for <strong>{retentionDays} days</strong>. All administrative actions (exports, status changes, monitoring toggles, and retention updates) are logged below.
        </p>
      </Panel>
      <Panel title="Admin audit events" subtitle="Tracks administrative actions in this session. Persistent immutable audit store requires backend deployment.">
        <TableTools rows={rows} columns={columns} filename="bluecode-audit-log.csv" statusFilter={common.statusFilter} setStatusFilter={common.setStatusFilter} statuses={["Info", "Notice"]} />
        <DataTable {...common} rows={rows} columns={columns} statusKey="level" />
      </Panel>
    </>
  );
}

export function AdminApp({ module = "dashboard", onNavigate, onLogout }) {
  const [searchState, setSearchState] = useState(() => ({ module, query: "" }));
  const query = getModuleSearchQuery(module, searchState);
  const setQuery = (value) => setSearchState({ module, query: value });
  const [range, setRange] = useState("30d");
  const [customStart, setCustomStart] = useState("2026-11-01");
  const [customEnd, setCustomEnd] = useState("2026-11-25");
  const [statusFilter, setStatusFilter] = useState("All statuses");
  const [sortBy, setSortBy] = useState("");
  const [sortDirection, setSortDirection] = useState("asc");
  const [page, setPage] = useState(1);
  const role = FOUNDER_ROLE;
  const [mobileOpen, setMobileOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [selectedStartupId, setSelectedStartupId] = useState(null);
  const [retentionDays, setRetentionDays] = useState(180);
  const [userStatusOverrides, setUserStatusOverrides] = useState({});
  const [auditLog, setAuditLog] = useState(() => adminApi.listAuditEvents());
  const activeModule = modules.find((item) => item.id === module) || modules[0];

  useEffect(() => {
    setQuery("");
    setStatusFilter("All statuses");
    setSortBy("");
    setSortDirection("asc");
    setPage(1);
    setSelectedUserId(null);
    setSelectedStartupId(null);
  }, [module]);

  const appendAuditEvent = (event, area, level = "Info") => {
    setAuditLog((prev) => [
      {
        id: `au-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        time: "Just now",
        actor: "Admin",
        event,
        area,
        level,
      },
      ...prev,
    ]);
  };

  const handleToggleSuspend = (user, nextStatus, reason) => {
    setUserStatusOverrides((prev) => ({ ...prev, [user.id]: nextStatus }));
    appendAuditEvent(
      nextStatus === "Suspended"
        ? `Suspended ${user.name} (${user.id})${reason ? ` · ${reason}` : ""}`
        : `Reactivated ${user.name} (${user.id})${reason ? ` · ${reason}` : ""}`,
      "User Management",
      nextStatus === "Suspended" ? "Notice" : "Info",
    );
  };

  const handleUpdateRetention = (days) => {
    setRetentionDays(days);
    appendAuditEvent(`Updated data retention policy to ${days} days`, "Operations & Governance", "Notice");
  };

  const handlePurgeExpiredLogs = () => {
    if (!window.confirm(`Purge illustrative audit entries older than ${retentionDays} days?`)) return;
    setAuditLog((prev) => prev.slice(0, 4));
    appendAuditEvent(`Purged expired demo logs per ${retentionDays}-day retention policy`, "Operations & Governance", "Notice");
  };

  const common = {
    search: query,
    sortBy,
    setSortBy,
    sortDirection,
    setSortDirection,
    page,
    setPage,
    statusFilter,
    setStatusFilter,
  };

  const navigateTo = (path) => {
    setMobileOpen(false);
    setNotificationsOpen(false);
    if (typeof onNavigate === "function") onNavigate(path);
  };

  const handleLogout = () => {
    if (!window.confirm("Are you sure you want to log out?")) return;
    setProfileOpen(false);
    if (typeof onLogout === "function") onLogout();
  };

  return (
    <div className="bluecode-admin">
      {mobileOpen ? <Button variant="ghost" className="admin-mobile-backdrop" aria-label="Close navigation" onClick={() => setMobileOpen(false)} /> : null}
      <aside className={`admin-sidebar ${mobileOpen ? "admin-sidebar-open" : ""}`}>
        <div className="admin-brand">
          <div className="brand-mark">
            <img src={blueCodeLogo.url} alt="BlueCode-OS logo" />
          </div>
          <div>
            <strong>BlueCode-OS</strong>
            <span>Sales intelligence workspace</span>
          </div>
          <Button variant="ghost" size="icon" className="admin-mobile-close" aria-label="Close navigation" onClick={() => setMobileOpen(false)}><X /></Button>
        </div>
        <div className="admin-workspace-tag"><ShieldCheck aria-hidden="true" /><span>Internal workspace</span><span className="admin-status-dot" /></div>
        <p className="admin-nav-label">WORKSPACE</p>
        <nav className="admin-nav" aria-label="Admin modules">
          {modules.map((item) => {
            const Icon = item.icon;
            return (
              <Button key={item.id} variant="ghost" className={`admin-nav-item ${item.id === module ? "is-active" : ""}`} aria-current={item.id === module ? "page" : undefined} onClick={() => navigateTo(item.path)}>
                <Icon aria-hidden="true" />
                <span>{item.label}</span>
                {item.id === module ? <span className="admin-nav-current" /> : null}
              </Button>
            );
          })}
        </nav>
        <div className="admin-sidebar-bottom">
          <div className="admin-security-note"><ShieldCheck aria-hidden="true" /><p><strong>Privacy first</strong><span>Customer records are illustrative and aggregated.</span></p></div>
        </div>
      </aside>
      <div className="admin-main-area">
        <header className="admin-topbar">
          <div className="admin-topbar-left">
            <Button variant="ghost" size="icon" className="admin-mobile-menu" aria-label="Open navigation" onClick={() => setMobileOpen(true)}><Menu /></Button>
            <div className="admin-breadcrumb"><span>BlueCode OS</span><ChevronRight aria-hidden="true" /><strong>{activeModule.label}</strong></div>
          </div>
          <div className="admin-topbar-right">
            <label className="admin-search">
              <Search aria-hidden="true" />
              <input type="search" aria-label="Search current module" placeholder="Search current module" value={query} onChange={(event) => { setQuery(event.target.value); setPage(1); }} />
              {query ? <Button variant="ghost" size="icon" aria-label="Clear search" onClick={() => setQuery("")}><X /></Button> : null}
            </label>
            <div className="admin-role-badge">
              <ShieldCheck aria-hidden="true" />
              <span>Admin</span>
            </div>
            <div className="admin-notification-wrap">
              <Button variant="outline" size="icon" className="admin-notification-button" aria-label="Notifications" aria-expanded={notificationsOpen} onClick={() => setNotificationsOpen((open) => !open)}><Bell aria-hidden="true" /><span /></Button>
              {notificationsOpen ? <div className="admin-notification-popover" role="status"><strong>System overview</strong><span>All sample provider monitors are available.</span><span>1 illustrative billing reminder is due for review.</span></div> : null}
            </div>
            <div className="admin-user-menu">
              <button
                type="button"
                className="admin-user-chip"
                aria-label="Admin profile"
                aria-haspopup="menu"
                aria-expanded={profileOpen}
                onClick={() => setProfileOpen((open) => !open)}
              >
                <span className="admin-user-avatar" title="Admin">A</span>
                <span>
                  <strong>Admin</strong>
                  <small>Full Platform Access</small>
                </span>
              </button>
              {profileOpen ? (
                <div className="admin-profile-menu" role="menu" aria-label="Admin profile options">
                  <button type="button" className="admin-profile-menu-item" role="menuitem" onClick={handleLogout}>
                    <LogOut aria-hidden="true" />
                    <span>Logout</span>
                  </button>
                </div>
              ) : null}
            </div>
          </div>
        </header>
        <main className="admin-content">
          <div className="admin-demo-banner"><span className="admin-demo-indicator" /><p><strong>Illustrative admin preview</strong><span>Sample data only · No customer systems or live APIs are connected</span></p><span className="admin-demo-badge">DEMO DATA</span></div>
          <div className="admin-module-content">
            {module === "dashboard" ? <Dashboard onNavigate={navigateTo} range={range} setRange={setRange} customStart={customStart} setCustomStart={setCustomStart} customEnd={customEnd} setCustomEnd={setCustomEnd} search={query} /> : null}
            {module === "users" ? (
              selectedUserId ? (
                <UserProfileView
                  userId={selectedUserId}
                  search={query}
                  userStatusOverrides={userStatusOverrides}
                  onBack={() => setSelectedUserId(null)}
                  onToggleSuspend={handleToggleSuspend}
                  range={range}
                  setRange={setRange}
                  customStart={customStart}
                  setCustomStart={setCustomStart}
                  customEnd={customEnd}
                  setCustomEnd={setCustomEnd}
                />
              ) : (
                <UsersPage
                  search={query}
                  statusFilter={statusFilter}
                  setStatusFilter={setStatusFilter}
                  userStatusOverrides={userStatusOverrides}
                  onSelectUser={(id) => setSelectedUserId(id)}
                />
              )
            ) : null}
            {module === "startups" ? (
              selectedStartupId ? (
                <StartupReportView
                  startupId={selectedStartupId}
                  backLabel="Back to Startup Management"
                  onBack={() => setSelectedStartupId(null)}
                  range={range}
                  setRange={setRange}
                  customStart={customStart}
                  setCustomStart={setCustomStart}
                  customEnd={customEnd}
                  setCustomEnd={setCustomEnd}
                  search={query}
                  onAuditAction={appendAuditEvent}
                />
              ) : (
                <StartupsPage
                  common={common}
                  onSelectStartup={(id) => setSelectedStartupId(id)}
                  onAuditAction={appendAuditEvent}
                />
              )
            ) : null}
            {module === "activity" ? (
              selectedStartupId ? (
                <StartupReportView
                  startupId={selectedStartupId}
                  backLabel="Back to User Activity"
                  onBack={() => setSelectedStartupId(null)}
                  range={range}
                  setRange={setRange}
                  customStart={customStart}
                  setCustomStart={setCustomStart}
                  customEnd={customEnd}
                  setCustomEnd={setCustomEnd}
                  search={query}
                  onAuditAction={appendAuditEvent}
                />
              ) : (
                <ActivityPage
                  common={common}
                  onSelectStartup={(id) => setSelectedStartupId(id)}
                  onAuditAction={appendAuditEvent}
                />
              )
            ) : null}
            {module === "ai-usage" ? <AiUsagePage common={common} range={range} setRange={setRange} customStart={customStart} setCustomStart={setCustomStart} customEnd={customEnd} setCustomEnd={setCustomEnd} /> : null}
            {module === "prospects" ? <ProspectsPage common={common} /> : null}
            {module === "email" ? <EmailActivityPage common={common} /> : null}
            {module === "subscriptions" ? <SubscriptionsPage common={common} /> : null}
            {module === "apis" ? <ApisPage common={common} /> : null}
            {module === "analytics" ? <AnalyticsPage common={common} range={range} setRange={setRange} customStart={customStart} setCustomStart={setCustomStart} customEnd={customEnd} setCustomEnd={setCustomEnd} /> : null}
            {module === "support" ? (
              <SupportPage
                common={common}
                auditEvents={auditLog}
                retentionDays={retentionDays}
                onUpdateRetention={handleUpdateRetention}
                onPurgeExpiredLogs={handlePurgeExpiredLogs}
                onAuditAction={appendAuditEvent}
              />
            ) : null}
          </div>
          <footer className="admin-footer"><span>BlueCode OS internal admin workspace</span><span><ShieldCheck aria-hidden="true" /> Admin · Full administrative access</span></footer>
        </main>
      </div>
    </div>
  );
}