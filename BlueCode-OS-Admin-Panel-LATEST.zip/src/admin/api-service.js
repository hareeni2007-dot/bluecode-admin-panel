import {
  aiUsage,
  apiUsage,
  auditEvents,
  dashboardSummary,
  emailActivity,
  featureUsage,
  prospectActivity,
  registeredUsers,
  startups,
  subscriptions,
  trendByRange,
  userActivity,
} from "./mock-data.js";
import {
  calculateEngagementScore,
  deriveEngagementBehaviors,
  getEngagementBreakdown,
  getEngagementTier,
  getUpgradeOpportunity,
  isInactiveStartup,
} from "./engagement.js";

/**
 * BlueCode OS - Founder-Only Administration Architecture
 *
 * Fixed role definition: Only Founder Admin is supported.
 * Multiple administrative roles (Super Admin, Support Admin, Viewer) are retired.
 * Public admin registration is strictly prohibited.
 */
export const FOUNDER_ROLE = "Founder Admin";

export const DEFAULT_FOUNDER_IDENTITY = {
  name: "Admin",
  role: FOUNDER_ROLE,
  email: "founder@bluecode.internal",
  hasFullAccess: true,
};

/**
 * Evaluates whether a session account holds authorized founder admin privileges.
 * Regular startup user accounts or unverified sessions are rejected.
 */
export function verifyFounderAuthorization(sessionUser) {
  if (!sessionUser) {
    return {
      authorized: false,
      reason: "No active session detected. Access restricted to authorized founder account.",
    };
  }

  const role = sessionUser.role || "";
  const isFounder = role === FOUNDER_ROLE || role === "founder_admin";
  if (!isFounder) {
    return {
      authorized: false,
      reason: "Access denied. Regular startup accounts cannot access founder administration features.",
    };
  }

  return {
    authorized: true,
    user: sessionUser,
  };
}

export const adminAuth = {
  getRole: () => FOUNDER_ROLE,

  getCurrentFounder: () => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("bluecode_founder_session");
      if (stored) {
        try {
          const parsed = JSON.parse(stored);
          if (parsed && (parsed.role === FOUNDER_ROLE || parsed.role === "founder_admin")) {
            return parsed;
          }
        } catch {
          // ignore corrupted storage
        }
      }

      const startupUserSession = localStorage.getItem("blueCodeActiveSessionV1");
      if (startupUserSession && !startupUserSession.toLowerCase().includes("founder")) {
        return null;
      }
    }

    return DEFAULT_FOUNDER_IDENTITY;
  },

  isFounderAuthorized: () => {
    const current = adminAuth.getCurrentFounder();
    const result = verifyFounderAuthorization(current);
    return result.authorized;
  },
};

/**
 * Computes date-range multiplier for demo usage metrics when switching
 * between 7-day, 30-day, 90-day, and custom date windows.
 */
export function getRangeFactor(range, customStart, customEnd) {
  if (range === "7d") return 0.28;
  if (range === "90d") return 2.75;
  if (range === "custom" && customStart && customEnd) {
    const start = new Date(customStart);
    const end = new Date(customEnd);
    const days = Math.max(1, Math.round((end - start) / (1000 * 60 * 60 * 24)) + 1);
    return Math.min(3, Math.max(0.1, Number((days / 30).toFixed(2))));
  }
  return 1;
}

/**
 * Joins registered users with their corresponding startup and subscription records
 * (single source of truth; no duplicate startup or subscription database).
 */
export function enrichUserRecord(user, statusOverrides = {}) {
  const startup = startups.find((item) => item.id === user.startupId) || null;
  const subscription = subscriptions.find((item) => item.startupId === user.startupId) || null;
  const effectiveStatus = statusOverrides[user.id] || user.status;

  return {
    ...user,
    status: effectiveStatus,
    startupName: startup?.name || "Unassigned Workspace",
    startupPlan: subscription?.plan || startup?.plan || "Starter",
    startupStatus: startup?.status || "Active",
    startupActiveUsers: startup?.activeUsers || 1,
    startup,
    subscription,
  };
}

/**
 * Aggregates a tenant-isolated activity & engagement report for a single startup
 * from available activity records (no cross-tenant data leakage).
 */
export function buildStartupReport(startup) {
  if (!startup) return null;

  const tenantUsers = registeredUsers.filter((u) => u.startupId === startup.id);
  const subscription = subscriptions.find((s) => s.startupId === startup.id) || null;
  const prospectRecord = prospectActivity.find((p) => p.startup === startup.name) || null;
  const emailRecord = emailActivity.find((e) => e.startup === startup.name) || null;
  const aiRecord = aiUsage.find((a) => a.startup === startup.name) || null;
  const activityRecord = userActivity.find((a) => a.startup === startup.name) || null;

  const behaviors = deriveEngagementBehaviors({
    startup,
    users: tenantUsers,
    prospectRecord,
    emailRecord,
    activityRecord,
  });
  const score = calculateEngagementScore(behaviors);
  const tier = getEngagementTier(score);
  const breakdown = getEngagementBreakdown(behaviors);
  const inactivity = isInactiveStartup(startup, activityRecord);
  const upgrade = getUpgradeOpportunity({ startup, subscription, score, aiRecord });

  const icpsCreated = tenantUsers.reduce((sum, u) => sum + (u.featureUsage?.icpsCreated || 0), 0);

  return {
    ...startup,
    users: tenantUsers,
    subscription,
    behaviors,
    score,
    tier,
    breakdown,
    inactivity,
    upgrade,
    metrics: {
      icpsCreated,
      prospectsResearched: prospectRecord?.researched ?? startup.prospectsResearched ?? 0,
      decisionMakersIdentified: prospectRecord?.decisionMakers ?? 0,
      prospectsQualified: prospectRecord?.qualified ?? 0,
      buyingSignalsAnalyzed: prospectRecord?.buyingSignals ?? 0,
      emailDraftsGenerated: emailRecord?.drafts ?? startup.emailDrafts ?? 0,
      emailsApproved: emailRecord?.approved ?? 0,
      emailsSent: emailRecord?.sent ?? 0,
      repliesRecorded: emailRecord?.replies ?? 0,
      aiRequests: aiRecord?.requests ?? 0,
      aiTokens: aiRecord?.tokens ?? 0,
      aiCost: aiRecord?.cost ?? startup.aiSpend ?? 0,
      aiFailedRequests: aiRecord?.failedRequests ?? 0,
      aiBudgetLimit: aiRecord?.budgetLimit ?? 0,
      aiProvider: aiRecord?.provider || "Anthropic Claude / OpenAI",
      hunterCredits: startup.hunterCredits ?? 0,
      sessions: activityRecord?.sessions ?? 0,
      activeDays: activityRecord?.activeDays ?? 0,
    },
  };
}

/**
 * Replace these deterministic mock readers with authenticated service calls
 * once the secure backend API is deployed.
 */
export const adminApi = {
  getDashboardSummary: () => dashboardSummary,
  listStartups: () => startups,
  listStartupsWithEngagement: () => startups.map((startup) => buildStartupReport(startup)),
  getStartupReport: (startupId) => {
    const startup = startups.find((item) => item.id === startupId);
    return buildStartupReport(startup);
  },
  listUsers: (statusOverrides = {}) => registeredUsers.map((user) => enrichUserRecord(user, statusOverrides)),
  getUserById: (userId, statusOverrides = {}) => {
    const user = registeredUsers.find((item) => item.id === userId);
    return user ? enrichUserRecord(user, statusOverrides) : null;
  },
  listUserActivity: () => userActivity,
  listAiUsage: () => aiUsage,
  listProspectActivity: () => prospectActivity,
  listEmailActivity: () => emailActivity,
  listSubscriptions: () => subscriptions,
  listApiUsage: () => apiUsage,
  listAuditEvents: () => auditEvents,
  listFeatureUsage: () => featureUsage,
  getUsageTrend: (range = "30d") => trendByRange[range] ?? trendByRange["30d"],
};

export function downloadCsv(rows, filename) {
  if (typeof document === "undefined" || rows.length === 0) return;

  const headers = Object.keys(rows[0]);
  const quote = (value) => `"${String(value ?? "").replaceAll('"', '""')}"`;
  const content = [
    headers.map(quote).join(","),
    ...rows.map((row) => headers.map((header) => quote(row[header])).join(",")),
  ].join("\n");
  const file = new Blob([content], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(file);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}
